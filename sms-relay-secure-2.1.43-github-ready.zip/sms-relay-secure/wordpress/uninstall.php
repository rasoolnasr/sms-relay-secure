<?php
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
global $wpdb;
foreach(['devices','messages','commands','reads','receipts','presence','accounts','account_tokens','account_devices','challenges','account_limits','account_billing'] as $t)$wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'srs_'.$t);
wp_clear_scheduled_hook('srs_cleanup');

delete_option('srs_schema');

// Remove device metadata, caches and sessions created by this plugin only.
$names=$wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'srs\_%' OR option_name LIKE '\_transient\_srs\_%' OR option_name LIKE '\_transient\_timeout\_srs\_%'");
foreach($names as $name)delete_option($name);
