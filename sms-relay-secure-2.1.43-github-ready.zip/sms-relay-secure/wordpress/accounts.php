<?php
if (!defined('ABSPATH')) exit;
/** Private-test onboarding. No WordPress user, administrator privilege or E2EE key is created here. */
final class SRS_Accounts {
 const POLICY='2026-10-11';
 static function table($name){return SRS_Bridge::table($name);}
 static function error($name,$status=400){return new WP_Error($name,$name,['status'=>$status]);}
 static function install(){
  global $wpdb;$cs=$wpdb->get_charset_collate();
  dbDelta('CREATE TABLE '.self::table('accounts')." (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   email varchar(254) NOT NULL,
   created_at bigint(20) NOT NULL,
   trial_until bigint(20) NOT NULL,
   state varchar(16) NOT NULL DEFAULT 'active',
   policy varchar(20) NOT NULL,
   PRIMARY KEY  (id),
   UNIQUE KEY email (email)
  ) $cs;");
  dbDelta('CREATE TABLE '.self::table('account_tokens')." (
   token_hash char(64) NOT NULL,
   account_id bigint(20) unsigned NOT NULL,
   expires_at bigint(20) NOT NULL,
   issued_at bigint(20) NOT NULL,
   PRIMARY KEY  (token_hash),
   KEY account_id (account_id)
  ) $cs;");
  dbDelta('CREATE TABLE '.self::table('account_devices')." (
   account_id bigint(20) unsigned NOT NULL,
   install_hash char(64) NOT NULL,
   device_id bigint(20) unsigned NOT NULL,
   PRIMARY KEY  (account_id,install_hash),
   UNIQUE KEY device_id (device_id)
  ) $cs;");
  dbDelta('CREATE TABLE '.self::table('challenges')." (
   id char(64) NOT NULL,
   email varchar(254) NOT NULL,
   code_hash char(64) NOT NULL,
   expires_at bigint(20) NOT NULL,
   attempts int NOT NULL DEFAULT 0,
   PRIMARY KEY  (id),
   KEY expires_at (expires_at)
  ) $cs;");
  dbDelta('CREATE TABLE '.self::table('account_limits')." (
   bucket char(64) NOT NULL,
   count int NOT NULL,
   expires_at bigint(20) NOT NULL,
   PRIMARY KEY  (bucket),
   KEY expires_at (expires_at)
  ) $cs;");
 }
 static function schema_ready(){global $wpdb;$required=['accounts'=>['id','email','trial_until','state','policy'],'account_tokens'=>['token_hash','account_id','issued_at','expires_at'],'account_devices'=>['account_id','device_id','install_hash'],'challenges'=>['id','code_hash','attempts','expires_at'],'account_limits'=>['bucket','count','expires_at'],'account_billing'=>['account_id','token_hash','token_cipher','expires_at','checked_at']];foreach($required as $table=>$names){$rows=$wpdb->get_results('SHOW COLUMNS FROM '.self::table($table),ARRAY_A);if(!is_array($rows)||!empty($wpdb->last_error)||array_diff($names,array_column($rows,'Field')))return false;}return true;}
 static function routes(){
  foreach(['start'=>'public_permission','verify'=>'public_permission','status'=>'auth','bootstrap'=>'auth','devices'=>'auth','revoke'=>'auth','delete'=>'auth','logout'=>'auth'] as $route=>$permission){
   register_rest_route('sms-relay-secure/v1','/account/'.$route,['methods'=>'POST','permission_callback'=>[__CLASS__,$permission],'callback'=>[__CLASS__,$route]]);
  }
 }
 static function enabled(){return get_option('srs_customer_signup',false)===true||get_option('srs_customer_signup',false)==='1';}
 static function public_permission($r){if(!is_ssl())return self::error('https_required',403);return true;}
 static function body($r){if(strlen($r->get_body())>4096)return self::error('too_large',413);$b=$r->get_json_params();return is_array($b)?$b:self::error('invalid');}
 static function hex($v){return is_string($v)&&preg_match('/^[a-f0-9]{64}$/D',$v);}
 static function email($v){if(!is_string($v)||strlen($v)>254)return false;$v=strtolower(trim($v));return is_email($v)?$v:false;}
 static function code_hash($id,$code){return hash_hmac('sha256',$id.'|'.$code,wp_salt('auth'));}
 // Atomic fixed-window counters, unlike read-modify-write transients. Never trust forwarded IP headers.
 static function limit($subject,$maximum,$window){
  global $wpdb;$bucket=hash_hmac('sha256',$subject.'|'.intdiv(time(),$window),wp_salt('auth'));$t=self::table('account_limits');
  if($wpdb->query($wpdb->prepare("INSERT INTO $t (bucket,count,expires_at) VALUES (%s,1,%d) ON DUPLICATE KEY UPDATE count=count+1",$bucket,time()+$window*2))===false)return false;
  $n=$wpdb->get_var($wpdb->prepare("SELECT count FROM $t WHERE bucket=%s",$bucket));return $n!==null&&(int)$n<=$maximum;
 }
 static function start($r){
  $b=self::body($r);if(is_wp_error($b))return $b;$email=self::email($b['email']??null);if(!$email)return self::error('invalid_email');
  if(!self::limit('mail-ip|'.($_SERVER['REMOTE_ADDR']??'unknown'),10,3600)||!self::limit('mail-email|'.$email,3,600))return self::error('rate_limit',429);
  global $wpdb;$id=bin2hex(random_bytes(32));$code=sprintf('%06d',random_int(0,999999));$expires=time()+600;
  if(!$wpdb->insert(self::table('challenges'),['id'=>$id,'email'=>$email,'code_hash'=>self::code_hash($id,$code),'expires_at'=>$expires]))return self::error('storage',503);
  $sent=wp_mail($email,'SMS Relay Secure — verification code',"Your sign-in code is: $code\nIt expires in 10 minutes. Never share this code. If you did not request it, ignore this email.");
  if(!$sent){$wpdb->delete(self::table('challenges'),['id'=>$id]);return self::error('email_unavailable',503);}
  return ['ok'=>true,'challenge'=>$id,'expires_in'=>600,'policy'=>self::POLICY];
 }
 static function verify($r){
  $b=self::body($r);if(is_wp_error($b))return $b;$id=$b['challenge']??null;$code=$b['code']??null;
  if(!self::hex($id)||!is_string($code)||!preg_match('/^[0-9]{6}$/D',$code)||($b['policy']??null)!==self::POLICY)return self::error('invalid');
  if(!self::limit('verify-ip|'.($_SERVER['REMOTE_ADDR']??'unknown'),30,600))return self::error('rate_limit',429);
  global $wpdb;$t=self::table('challenges');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%s",$id),ARRAY_A);
  if(!$row||(int)$row['expires_at']<time()||(int)$row['attempts']>=5)return self::error('code_invalid',401);
  // Consume an attempt with CAS before checking; parallel guesses cannot exceed five.
  if($wpdb->query($wpdb->prepare("UPDATE $t SET attempts=attempts+1 WHERE id=%s AND attempts=%d AND expires_at>=%d",$id,(int)$row['attempts'],time()))!==1)return self::error('code_invalid',401);
  if(!hash_equals($row['code_hash'],self::code_hash($id,$code)))return self::error('code_invalid',401);
  if($wpdb->query($wpdb->prepare("DELETE FROM $t WHERE id=%s AND attempts=%d",$id,(int)$row['attempts']+1))!==1)return self::error('code_invalid',401);
  $a=self::table('accounts');$now=time();
  $known=$wpdb->get_row($wpdb->prepare("SELECT * FROM $a WHERE email=%s",$row['email']),ARRAY_A);
  if(!$known&&!self::enabled())return self::error('signup_unavailable',503);
  $trial=get_option('srs_trial_used_'.hash_hmac('sha256',$row['email'],wp_salt('auth')),false)?$now-1:$now+259200;
  if($wpdb->query($wpdb->prepare("INSERT INTO $a (email,created_at,trial_until,state,policy) VALUES (%s,%d,%d,'active',%s) ON DUPLICATE KEY UPDATE email=email",$row['email'],$now,$trial,self::POLICY))===false)return self::error('storage',503);
  $account=$wpdb->get_row($wpdb->prepare("SELECT * FROM $a WHERE email=%s",$row['email']),ARRAY_A);
  if(!$account||!in_array($account['state'],['active','deleting'],true))return self::error('account_unavailable',403);
  $token=bin2hex(random_bytes(32));$expires=$now+2592000;
  if(!$wpdb->insert(self::table('account_tokens'),['token_hash'=>hash('sha256',$token),'account_id'=>$account['id'],'expires_at'=>$expires,'issued_at'=>$now]))return self::error('storage',503);
  return ['ok'=>true,'token'=>$token,'expires_at'=>$expires,'trial_until'=>(int)$account['trial_until'],'account_id'=>(int)$account['id'],'account_state'=>$account['state'],'billing_ready'=>SRS_Billing::ready(),'billing_account'=>SRS_Billing::account_id($account['id'])];
 }
 static function auth($r){
  if(!is_ssl())return self::error('https_required',403);$token=$r->get_header('x-msi-key');if(!self::hex($token))return self::error('unauthorized',401);
  global $wpdb;$a=self::table('accounts');$t=self::table('account_tokens');$account=$wpdb->get_row($wpdb->prepare("SELECT a.*,t.issued_at AS session_issued_at FROM $a a JOIN $t t ON a.id=t.account_id WHERE t.token_hash=%s AND t.expires_at>=%d",hash('sha256',$token),time()),ARRAY_A);
  if(!$account||!in_array($account['state'],['active','deleting'],true))return self::error('unauthorized',401);
  // An interrupted deletion can be resumed but cannot create new devices.
  if($account['state']==='deleting'&&substr($r->get_route(),-7)!=='/delete')return self::error('account_deleting',403);
  $r->set_param('_account',$account);return true;
 }
 static function status($r){$a=$r->get_param('_account');return ['ok'=>true,'account_id'=>(int)$a['id'],'trial_until'=>(int)$a['trial_until'],'trial_active'=>SRS_Billing::entitled($a),'billing_ready'=>SRS_Billing::ready(),'billing_account'=>SRS_Billing::account_id($a['id']),'policy'=>self::POLICY];}
 static function lock($id){global $wpdb;return (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,3)','srs_account_'.hash('sha256',self::table('accounts').'|'.$id)))===1;}
 static function unlock($id){global $wpdb;$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)','srs_account_'.hash('sha256',self::table('accounts').'|'.$id)));}
 static function bootstrap($r){
  $b=self::body($r);if(is_wp_error($b))return $b;$a=$r->get_param('_account');$install=$b['install_id']??null;$server=$b['server_key']??null;$client=$b['client_key']??null;$label=$b['label']??null;
  if(!self::hex($install)||!self::hex($server)||!self::hex($client)||hash_equals($server,$client)||!is_string($label)||strlen($label)>100||trim($label)==='')return self::error('invalid');
  if(!SRS_Billing::entitled($a))return self::error('trial_expired',403);
  if(!self::lock($a['id']))return self::error('busy',409);
  try{
   global $wpdb;$ownership=self::table('account_devices');$devices=self::table('devices');
   // Re-read under lock: account deletion wins over a stale authenticated request.
   if($wpdb->get_var($wpdb->prepare('SELECT state FROM '.self::table('accounts').' WHERE id=%d',$a['id']))!=='active')return self::error('account_unavailable',403);
   $existing=$wpdb->get_row($wpdb->prepare("SELECT d.* FROM $devices d JOIN $ownership o ON d.id=o.device_id WHERE o.account_id=%d AND o.install_hash=%s",$a['id'],hash('sha256',$install)),ARRAY_A);
   if($existing){if(!hash_equals($existing['server_hash'],hash('sha256',$server))||!hash_equals($existing['client_hash'],hash('sha256',$client)))return self::error('device_conflict',409);return ['ok'=>true,'device_id'=>(int)$existing['id'],'label'=>$existing['label'],'duplicate'=>true];}
   $count=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ownership WHERE account_id=%d",$a['id']));if($count===null)return self::error('storage',503);if((int)$count>=2)return self::error('device_limit',403);
   $secrets=SRS_Bridge::enc(['server'=>$server,'client'=>$client]);if($secrets===false)return self::error('storage',503);
   if(!$wpdb->insert($devices,['label'=>sanitize_text_field($label),'server_hash'=>hash('sha256',$server),'client_hash'=>hash('sha256',$client),'secrets'=>$secrets,'enabled'=>1]))return self::error('storage',503);
   $device=(int)$wpdb->insert_id;
   if(!$wpdb->insert($ownership,['account_id'=>$a['id'],'install_hash'=>hash('sha256',$install),'device_id'=>$device])){$wpdb->delete($devices,['id'=>$device]);return self::error('storage',503);}
   update_option('srs_initial_'.$device,5,false);return ['ok'=>true,'device_id'=>$device,'label'=>sanitize_text_field($label),'duplicate'=>false];
  }finally{self::unlock($a['id']);}
 }
 static function device_permission($device){
  global $wpdb;$o=self::table('account_devices');$a=self::table('accounts');$row=$wpdb->get_row($wpdb->prepare("SELECT a.id,a.state,a.trial_until FROM $a a JOIN $o o ON a.id=o.account_id WHERE o.device_id=%d",$device),ARRAY_A);
  if(!empty($wpdb->last_error))return self::error('storage',503);
  if(!$row)return true; // Legacy/admin-managed inboxes retain their existing behavior.
  if($row['state']!=='active')return self::error('account_unavailable',403);
  return SRS_Billing::entitled($row)?true:self::error('trial_expired',403);
 }
 static function devices($r){global $wpdb;$a=$r->get_param('_account');$o=self::table('account_devices');$d=self::table('devices');$rows=$wpdb->get_results($wpdb->prepare("SELECT d.id,d.label,d.enabled,d.last_seen FROM $d d JOIN $o o ON d.id=o.device_id WHERE o.account_id=%d ORDER BY d.id DESC",$a['id']),ARRAY_A);if(!is_array($rows)||!empty($wpdb->last_error))return self::error('storage',503);return ['ok'=>true,'devices'=>$rows];}
 static function owned($account,$device){global $wpdb;return (int)$wpdb->get_var($wpdb->prepare('SELECT device_id FROM '.self::table('account_devices').' WHERE account_id=%d AND device_id=%d',$account,$device))===$device&&$device>0;}
 static function revoke($r){$b=self::body($r);if(is_wp_error($b))return $b;$a=$r->get_param('_account');$id=$b['device_id']??null;if(!is_int($id)||!self::owned($a['id'],$id))return self::error('not_found',404);global $wpdb;$ok=$wpdb->update(self::table('devices'),['enabled'=>0],['id'=>$id]);return $ok===false?self::error('storage',503):['ok'=>true];}
 static function logout($r){global $wpdb;$ok=$wpdb->delete(self::table('account_tokens'),['token_hash'=>hash('sha256',$r->get_header('x-msi-key'))]);return $ok===false?self::error('storage',503):['ok'=>true];}
 static function delete($r){
  $b=self::body($r);if(is_wp_error($b))return $b;if(($b['confirm']??'')!=='DELETE')return self::error('confirmation_required');$a=$r->get_param('_account');if((int)($a['session_issued_at']??0)<time()-600)return self::error('recent_login_required',401);if(!self::lock($a['id']))return self::error('busy',409);
  try{
   global $wpdb;$o=self::table('account_devices');$accounts=self::table('accounts');
   if($wpdb->update($accounts,['state'=>'deleting'],['id'=>$a['id']])===false)return self::error('storage',503);
   $ids=$wpdb->get_col($wpdb->prepare("SELECT device_id FROM $o WHERE account_id=%d",$a['id']));if(!is_array($ids)||!empty($wpdb->last_error))return self::error('storage',503);
   foreach($ids as $id){$res=SRS_Bridge::erase_device((int)$id);if(is_wp_error($res))return $res;}
   if($wpdb->delete(self::table('account_billing'),['account_id'=>$a['id']])===false)return self::error('storage',503);
   if($wpdb->delete($o,['account_id'=>$a['id']])===false)return self::error('storage',503);
   if($wpdb->delete(self::table('challenges'),['email'=>$a['email']])===false)return self::error('storage',503);
   // Keep a keyed, non-reversible email tombstone outside the live account to prevent renewing trials by deleting/recreating.
   update_option('srs_trial_used_'.hash_hmac('sha256',$a['email'],wp_salt('auth')),true,false);
   if($wpdb->delete($accounts,['id'=>$a['id']])===false)return self::error('storage',503);
   $wpdb->delete(self::table('account_tokens'),['account_id'=>$a['id']]);
   return ['ok'=>true,'deleted'=>true];
  }finally{self::unlock($a['id']);}
 }
 static function cleanup(){global $wpdb;foreach(['challenges','account_tokens','account_limits'] as $kind)$wpdb->query($wpdb->prepare('DELETE FROM '.self::table($kind).' WHERE expires_at<%d',time()));}
 static function menu(){add_submenu_page('sms-relay-secure','Customer onboarding','راه‌اندازی مشتریان','manage_options','srs-customers',[__CLASS__,'admin']);}
 static function admin(){
  if(!current_user_can('manage_options'))return;
  if($_SERVER['REQUEST_METHOD']==='POST'){check_admin_referer('srs_customers');update_option('srs_customer_signup',isset($_POST['enabled'])?'1':'0',false);}
  echo '<div class="wrap" dir="rtl"><h1>راه‌اندازی خودکار مشتریان — آزمایش خصوصی</h1><p>ثبت‌نام با کد ایمیل، صندوق مستقل و سه روز آزمایش. خرید Google Play به محصولات و کلید سرویس حساب توسعه‌دهنده نیاز دارد؛ تا انجام آزمون واقعی برای فروش عمومی آماده نیست. ارسال ایمیل هاست باید کار کند.</p><form method="post">';wp_nonce_field('srs_customers');echo '<label><input type="checkbox" name="enabled" value="1" '.checked(self::enabled(),true,false).'> فعال‌سازی ثبت‌نام آزمایشی</label> ';submit_button('ذخیره');echo '</form><p>صفحه حذف حساب: یک برگه با شورت‌کد <code>[srs_account_delete]</code> بسازید. محتوای پیام‌ها در مرورگر نمایش داده نمی‌شود.</p></div>';
 }
}

add_shortcode('srs_account_delete',function(){
 wp_enqueue_script('srs-account-delete',plugins_url('account-delete.js',__FILE__),[],'2.1.43',true);
 return '<section dir="rtl" data-srs-account-delete data-endpoint="'.esc_url(rest_url('sms-relay-secure/v1/account/')).'"><h2>حذف حساب SMS Relay Secure</h2><p>حساب، تمام اتصال‌ها و پیام‌های فعال این سرویس حذف می‌شوند. پیامک‌های اصلی گوشی حذف نمی‌شوند. یک شناسه یک‌طرفه برای جلوگیری از تکرار دوره آزمایشی باقی می‌ماند. حذف نسخه‌های پشتیبان طبق سیاست منتشرشده سرویس‌دهنده انجام می‌شود.</p><label>ایمیل حساب <input type="email" data-email autocomplete="email"></label><p><label><input type="checkbox" data-consent> موافقم ایمیل برای تأیید مالکیت به این سایت ارسال شود.</label></p><button type="button" data-start>دریافت کد ایمیل</button><p><label>کد شش‌رقمی <input type="text" data-code inputmode="numeric" maxlength="6" autocomplete="one-time-code"></label> <button type="button" data-verify>تأیید حساب</button></p><p><label>برای حذف دائمی، DELETE بنویسید <input type="text" data-confirm autocomplete="off"></label> <button type="button" data-delete>حذف دائمی حساب</button></p><p data-status role="status" aria-live="polite"></p></section>';
});
