=== SMS Relay Secure ===
Tags: sms, android, gateway, encryption, remote messaging
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 2.1.41
License: GPL-2.0-or-later

Encrypted Android SMS forwarding and remote sending through a self-hosted WordPress relay.

== Description ==
Connect an Android SIM phone to trusted Android clients using your own HTTPS WordPress relay. QR pairing, dual-SIM selection and SMS history. Private-test build only. Matching Android app required. Trusted phones hold a shared encryption key; WordPress receives ciphertext and operational metadata. Browser content viewing, iOS gateway, per-client key revocation, billing and commercial licensing are not implemented. Original carrier SMS and endpoint devices are outside this encryption boundary.
Independent tables, options and API. Old Mobile SMS Inbox data is not migrated or deleted.

== Installation ==
Upload only sms-relay-secure-wordpress-2.1.41.zip in Plugins > Add New > Upload Plugin, activate, open SMS Relay Secure and add a new Android server. Install the matching private-test APK on both phones.

== Changelog ==
= 2.1.41 =
New product name, independent Android ID, WordPress plugin slug, API namespace, classes and storage. QR pairing retained.
