/* Account deletion only. No message content or E2EE key is handled in the browser. */
document.querySelectorAll('[data-srs-account-delete]').forEach(root => {
  const endpoint = root.dataset.endpoint;
  let challenge = '', token = '';
  const status = root.querySelector('[data-status]');
  const buttons = Array.from(root.querySelectorAll('button'));
  async function request(route, data) {
    buttons.forEach(b => b.disabled = true);
    status.textContent = 'در حال ارتباط…';
    try {
      const response = await fetch(endpoint + route, {
        method: 'POST', credentials: 'omit', cache: 'no-store',
        headers: {'Content-Type': 'application/json', 'X-MSI-Key': token},
        body: JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok || result.ok !== true) throw new Error(result.message || 'درخواست انجام نشد');
      return result;
    } finally { buttons.forEach(b => b.disabled = false); }
  }
  function failed(e) { status.textContent = 'انجام نشد: ' + e.message; }
  root.querySelector('[data-start]').addEventListener('click', async () => {
    if (!root.querySelector('[data-consent]').checked) { status.textContent = 'ابتدا ارسال ایمیل به این سایت را تأیید کنید.'; return; }
    try {
      const result = await request('start', {email: root.querySelector('[data-email]').value.trim()});
      challenge = result.challenge;
      status.textContent = 'کد ایمیل را وارد کنید؛ اعتبار ده دقیقه.';
    } catch (e) { failed(e); }
  });
  root.querySelector('[data-verify]').addEventListener('click', async () => {
    if (!challenge) { status.textContent = 'ابتدا کد ورود بگیرید.'; return; }
    try {
      const result = await request('verify', {challenge, code: root.querySelector('[data-code]').value.trim(), policy: '2026-10-11'});
      token = result.token;
      root.querySelector('[data-code]').value = '';
      challenge = '';
      status.textContent = 'حساب تأیید شد؛ برای حذف دائمی، عبارت DELETE را وارد کنید.';
    } catch (e) { failed(e); }
  });
  root.querySelector('[data-delete]').addEventListener('click', async () => {
    if (!token || root.querySelector('[data-confirm]').value !== 'DELETE') { status.textContent = 'ورود و عبارت DELETE لازم است.'; return; }
    if (!window.confirm('حساب، تمام اتصال‌ها و داده‌های فعال سایت برای همیشه حذف شوند؟')) return;
    try { await request('delete', {confirm: 'DELETE'}); token = ''; status.textContent = 'حساب و داده‌های فعال سایت حذف شدند. پیامک‌های اصلی گوشی حذف نمی‌شوند.'; }
    catch (e) { failed(e); }
  });
});
