<?php
if(!defined('ABSPATH'))exit;
/** Google Play subscriptions: fail closed unless a server-side Google response binds the purchase to this account. */
final class SRS_Billing {
 const PACKAGE='net.lingomaster.smsrelay.secure';
 const PRODUCTS=['sms_relay_monthly','sms_relay_yearly'];
 static function ready(){return defined('SRS_GOOGLE_SERVICE_ACCOUNT_FILE')&&is_string(SRS_GOOGLE_SERVICE_ACCOUNT_FILE)&&is_readable(SRS_GOOGLE_SERVICE_ACCOUNT_FILE);}
 static function account_id($id){return hash_hmac('sha256','play-account|'.home_url('/').'|'.$id,wp_salt('auth'));}
 static function install(){global $wpdb;$cs=$wpdb->get_charset_collate();dbDelta('CREATE TABLE '.SRS_Bridge::table('account_billing')." (
  account_id bigint(20) unsigned NOT NULL,
  token_hash char(64) NOT NULL,
  token_cipher text NOT NULL,
  product varchar(100) NOT NULL,
  expires_at bigint(20) NOT NULL,
  checked_at bigint(20) NOT NULL,
  PRIMARY KEY  (account_id),
  UNIQUE KEY token_hash (token_hash)
 ) $cs;");}
 static function routes(){register_rest_route('sms-relay-secure/v1','/account/purchase',['methods'=>'POST','permission_callback'=>['SRS_Accounts','auth'],'callback'=>[__CLASS__,'purchase']]);}
 static function b64($s){return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
 static function access_token(){
  if(!self::ready())return SRS_Accounts::error('billing_unavailable',503);
  $cached=SRS_Bridge::dec((string)get_transient('srs_google_oauth'));if(is_array($cached)&&($cached['until']??0)>time())return $cached['token'];
  // Service-account material is stored outside the public WordPress tree, never in APK or admin HTML.
  $path=realpath(SRS_GOOGLE_SERVICE_ACCOUNT_FILE);$root=realpath(ABSPATH);
  if(!$path||($root&&strpos($path,$root.DIRECTORY_SEPARATOR)===0)||filesize($path)>65536)return SRS_Accounts::error('billing_configuration',503);
  $key=json_decode(file_get_contents($path),true);if(!is_array($key)||!is_string($key['client_email']??null)||!is_string($key['private_key']??null))return SRS_Accounts::error('billing_configuration',503);
  $now=time();$head=self::b64(wp_json_encode(['alg'=>'RS256','typ'=>'JWT']));$payload=self::b64(wp_json_encode(['iss'=>$key['client_email'],'scope'=>'https://www.googleapis.com/auth/androidpublisher','aud'=>'https://oauth2.googleapis.com/token','iat'=>$now,'exp'=>$now+3600]));$input=$head.'.'.$payload;$signature='';
  if(!openssl_sign($input,$signature,$key['private_key'],OPENSSL_ALGO_SHA256))return SRS_Accounts::error('billing_configuration',503);
  $response=wp_remote_post('https://oauth2.googleapis.com/token',['timeout'=>15,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536,'body'=>['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$input.'.'.self::b64($signature)]]);
  if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)return SRS_Accounts::error('billing_verification_unavailable',503);
  $data=json_decode(wp_remote_retrieve_body($response),true);if(!is_array($data)||!is_string($data['access_token']??null)||empty($data['access_token']))return SRS_Accounts::error('billing_verification_unavailable',503);
  $encrypted=SRS_Bridge::enc(['token'=>$data['access_token'],'until'=>$now+min(3300,(int)($data['expires_in']??0))]);if($encrypted!==false)set_transient('srs_google_oauth',$encrypted,3300);return $data['access_token'];
 }
 static function google($token,$purchase,$product=null){
  $url='https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'.self::PACKAGE.'/purchases/';
  $url.=$product===null?'subscriptionsv2/tokens/'.rawurlencode($purchase):'subscriptions/'.rawurlencode($product).'/tokens/'.rawurlencode($purchase).':acknowledge';
  $response=wp_remote_request($url,['method'=>$product===null?'GET':'POST','headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>$product===null?null:'{}','timeout'=>15,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536]);
  if(is_wp_error($response))return SRS_Accounts::error('billing_verification_unavailable',503);$status=wp_remote_retrieve_response_code($response);if($status===404||$status===400)return SRS_Accounts::error('purchase_invalid',403);if($status!==200&&$status!==204)return SRS_Accounts::error('billing_verification_unavailable',503);
  if($product!==null)return ['ok'=>true];$data=json_decode(wp_remote_retrieve_body($response),true);return is_array($data)?$data:SRS_Accounts::error('billing_verification_unavailable',503);
 }
 static function validate($data,$account){
  if(!is_array($data)||!hash_equals(self::account_id($account),(string)($data['externalAccountIdentifiers']['obfuscatedExternalAccountId']??'')))return SRS_Accounts::error('purchase_account_mismatch',403);
  if(!in_array($data['subscriptionState']??'', ['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED'],true))return SRS_Accounts::error('purchase_inactive',403);
  $expires=0;$product='';foreach($data['lineItems']??[] as $item){if(!in_array($item['productId']??'',self::PRODUCTS,true))continue;try{$at=(new DateTimeImmutable($item['expiryTime']??'invalid'))->getTimestamp();}catch(Exception $e){continue;}if($at>$expires){$expires=$at;$product=$item['productId'];}}
  if($expires<=time()||$product==='')return SRS_Accounts::error('purchase_inactive',403);return ['expires_at'=>$expires,'product'=>$product];
 }
 static function verify($account,$purchase){
  $token=self::access_token();if(is_wp_error($token))return $token;$data=self::google($token,$purchase);if(is_wp_error($data))return $data;$valid=self::validate($data,$account);if(is_wp_error($valid))return $valid;
  if(($data['acknowledgementState']??'')!=='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED'){$ack=self::google($token,$purchase,$valid['product']);if(is_wp_error($ack))return $ack;}return $valid;
 }
 static function purchase($r){
  $body=SRS_Accounts::body($r);if(is_wp_error($body))return $body;$purchase=$body['purchase_token']??null;if(!is_string($purchase)||strlen($purchase)<16||strlen($purchase)>2048||preg_match('/[\x00-\x20\x7f]/',$purchase))return SRS_Accounts::error('invalid');
  $a=$r->get_param('_account');if(!SRS_Accounts::limit('purchase|'.$a['id'],10,600))return SRS_Accounts::error('rate_limit',429);
  $valid=self::verify($a['id'],$purchase);if(is_wp_error($valid))return $valid;
  if(!SRS_Accounts::lock($a['id']))return SRS_Accounts::error('busy',409);
  try{
   global $wpdb;if($wpdb->get_var($wpdb->prepare('SELECT state FROM '.SRS_Bridge::table('accounts').' WHERE id=%d',$a['id']))!=='active')return SRS_Accounts::error('account_unavailable',403);
   $cipher=SRS_Bridge::enc(['purchase'=>$purchase]);if($cipher===false)return SRS_Accounts::error('storage',503);
   $ok=$wpdb->replace(SRS_Bridge::table('account_billing'),['account_id'=>$a['id'],'token_hash'=>hash('sha256',$purchase),'token_cipher'=>$cipher,'product'=>$valid['product'],'expires_at'=>$valid['expires_at'],'checked_at'=>time()]);
   return $ok===false?SRS_Accounts::error('storage',503):['ok'=>true,'expires_at'=>$valid['expires_at'],'verified'=>true];
  }finally{SRS_Accounts::unlock($a['id']);}
 }
 static function entitled($account){
  if((int)$account['trial_until']>=time())return true;
  global $wpdb;$table=SRS_Bridge::table('account_billing');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE account_id=%d",$account['id']),ARRAY_A);if(!$row||!empty($wpdb->last_error))return false;
  // Refresh even after old expiry: an auto-renewal can arrive while both phones are unattended.
  if((int)$row['checked_at']>=time()-300)return (int)$row['expires_at']>time();
  if(!SRS_Accounts::lock($account['id']))return false;
  try{
   $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE account_id=%d",$account['id']),ARRAY_A);if(!$row)return false;
   if((int)$row['checked_at']>=time()-300)return (int)$row['expires_at']>time();
   $plain=SRS_Bridge::dec($row['token_cipher']);if(!is_array($plain)||!is_string($plain['purchase']??null))return false;
   $valid=self::verify($account['id'],$plain['purchase']);
   if(is_wp_error($valid)){$wpdb->update($table,['expires_at'=>0,'checked_at'=>time()],['account_id'=>$account['id'],'token_hash'=>$row['token_hash']]);return false;}
   if($wpdb->update($table,['expires_at'=>$valid['expires_at'],'checked_at'=>time(),'product'=>$valid['product']],['account_id'=>$account['id'],'token_hash'=>$row['token_hash']])===false)return false;
   return true;
  }finally{SRS_Accounts::unlock($account['id']);}
 }
}
