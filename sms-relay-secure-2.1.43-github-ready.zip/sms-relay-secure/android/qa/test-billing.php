<?php
define('ABSPATH',__DIR__);define('ARRAY_A',1);
class WP_Error {public $code;function __construct($c){$this->code=$c;}}
function is_wp_error($x){return $x instanceof WP_Error;}function home_url($path=''){return 'https://test.invalid'.$path;}function wp_salt(){return 'billing-test-salt';}
class SRS_Accounts {static function error($c,$s=400){return new WP_Error($c);}}
require $argv[1];$n=0;
function check($ok,$name){global $n;if(!$ok)throw new Exception($name);$n++;echo "PASS $name\n";}
$owner=7;$expiry=gmdate('Y-m-d\TH:i:s\Z',time()+3600);
$base=['externalAccountIdentifiers'=>['obfuscatedExternalAccountId'=>SRS_Billing::account_id($owner)],'subscriptionState'=>'SUBSCRIPTION_STATE_ACTIVE','lineItems'=>[['productId'=>'sms_relay_monthly','expiryTime'=>$expiry]]];
check(!SRS_Billing::ready(),'No credential means billing unavailable');
check(strlen(SRS_Billing::account_id(7))===64&&SRS_Billing::account_id(7)!==SRS_Billing::account_id(8),'Account obfuscation is distinct and stable');
check(SRS_Billing::validate($base,7)['product']==='sms_relay_monthly','Active allowed product accepted');
check(SRS_Billing::validate($base,8)->code==='purchase_account_mismatch','Purchase cannot be claimed by another customer');
$x=$base;unset($x['externalAccountIdentifiers']);check(SRS_Billing::validate($x,7)->code==='purchase_account_mismatch','Unbound purchase rejected');
foreach(['SUBSCRIPTION_STATE_PENDING','SUBSCRIPTION_STATE_PAUSED','SUBSCRIPTION_STATE_ON_HOLD','SUBSCRIPTION_STATE_EXPIRED','UNKNOWN'] as $state){$x=$base;$x['subscriptionState']=$state;check(SRS_Billing::validate($x,7)->code==='purchase_inactive','State '.$state.' rejected');}
foreach(['SUBSCRIPTION_STATE_CANCELED','SUBSCRIPTION_STATE_IN_GRACE_PERIOD'] as $state){$x=$base;$x['subscriptionState']=$state;check(SRS_Billing::validate($x,7)['expires_at']>time(),'Valid remaining entitlement in '.$state);}
$x=$base;$x['lineItems'][0]['expiryTime']=gmdate('c',time()-1);check(SRS_Billing::validate($x,7)->code==='purchase_inactive','Past expiry rejected');
$x=$base;$x['lineItems'][0]['expiryTime']='invalid';check(SRS_Billing::validate($x,7)->code==='purchase_inactive','Malformed expiry rejected');
$x=$base;$x['lineItems'][0]['productId']='foreign_product';check(SRS_Billing::validate($x,7)->code==='purchase_inactive','Other products cannot unlock service');
$x=$base;$x['lineItems']=[];check(SRS_Billing::validate($x,7)->code==='purchase_inactive','No entitlement line rejected');
check(is_wp_error(SRS_Billing::verify(7,'fake-purchase-token')),'Client receipt alone cannot activate service');
echo "$n billing validation checks passed; no real Google purchase was made.\n";
