package ir.privateinbox.sms;
import android.content.Context;
final class ReceiveStatus {
 static void record(Context c,String name,String value){c.getSharedPreferences("receive-status",0).edit().putString(name,value).apply();}
 static String now(){return java.time.Instant.now().toString();}
 static String progress(Context c){android.content.SharedPreferences p=c.getSharedPreferences("receive-status",0);int left=Outbox.count(c);String history=p.getString("history","تاریخچه هنوز بررسی نشده است");return history+"\n"+(left>0?"در حال انتقال: "+left+" رکورد باقی‌مانده":p.getString("history",null)==null?"در انتظار بررسی تاریخچه؛ هنوز پایان انتقال تأیید نشده است.":"انتقال پایان یافت؛ صف خالی است. دریافت پیام جدید فعال می‌ماند.");}
 static String summary(Context c){android.content.SharedPreferences p=c.getSharedPreferences("receive-status",0);java.io.File[] fs=Store.queue(c).listFiles((d,n)->n.endsWith(".sms"));return p.getString("history","تاریخچه هنوز بررسی نشده است")+"\n"+(fs!=null&&fs.length>0?"انتقال ادامه دارد: "+fs.length+" رکورد باقی‌مانده":"صف انتقال خالی است؛ انتقال رکوردهای ذخیره‌شده پایان یافت.")+"\nآخرین رویداد دریافت در برنامه: "+p.getString("broadcast","هنوز ثبت نشده")+"\nآخرین ذخیره پیام دریافتی: "+p.getString("stored","هنوز ثبت نشده")+"\nآخرین انتقال دریافت به وردپرس: "+p.getString("uploaded","هنوز ثبت نشده")+"\nصف انتقال گوشی: "+(fs==null?0:fs.length)+"\nوضعیت انتقال: "+p.getString("error","بدون خطای ثبت‌شده")+"\n"+c.getSharedPreferences("contact-status",0).getString("last","بررسی مخاطبان هنوز انجام نشده است.");}
}
