package ir.privateinbox.sms;
import android.content.*;import android.content.pm.PackageManager;import android.database.Cursor;import android.provider.Telephony;import org.json.*;
final class SmsHistory {
 static void enqueue(Context c,String sender,String message,long timestamp)throws Exception{enqueue(c,sender,message,timestamp,false);}
 static void enqueue(Context c,String sender,String message,long timestamp,boolean live)throws Exception{enqueue(c,sender,message,timestamp,live,-1);}
 static synchronized void enqueue(Context c,String sender,String message,long timestamp,boolean live,int sim)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!"server".equals(p.getString("role","client")))return;
  String id=Gateway.hash(Store.device(c)+"|"+sender+"|"+timestamp+"|"+message);
  String ledger="incoming_"+Gateway.hash(p.getString("site","")+"|"+p.getString("key","")+"|"+id);
  // A recorded message remains owned by the durable queue; scans never enqueue it again.
  if(p.getBoolean(ledger,false))return;
  boolean fresh=true;String name=ContactNames.lookup(c,sender);
  JSONObject body=new JSONObject().put("event_id",id).put("sender",sender).put("sender_name",name).put("message",message).put("sent_at",java.time.Instant.ofEpochMilli(timestamp).toString()).put("sim_id",sim);
  Outbox.add(c,p.getString("site",""),p.getString("key",""),"server/incoming",body,live||(fresh&&timestamp>=System.currentTimeMillis()-120000));
  if(!p.edit().putBoolean(ledger,true).putInt(ledger+"_sim",sim).putString(ledger+"_name",name).putBoolean(ledger+"_live",live||p.getBoolean(ledger+"_live",false)||(fresh&&timestamp>=System.currentTimeMillis()-120000)).commit())throw new java.io.IOException("ثبت سابقه انتقال انجام نشد");
  ReceiveStatus.record(c,"stored",ReceiveStatus.now());if(fresh&&timestamp>=System.currentTimeMillis()-120000)MessageAlerts.show(c,Gateway.hash(sender+"|"+timestamp+"|"+message),sender,name,message);
 }
 private static long lastFullScan=0;
 private static final java.util.concurrent.locks.ReentrantLock scanLock=new java.util.concurrent.locks.ReentrantLock();
 static void scan(Context c)throws Exception{
  if(c.checkSelfPermission(android.Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED){ReceiveStatus.record(c,"error","برای انتقال تا ۵۰۰ پیامک قبلی هر شماره و بررسی خودکار صندوق، مجوز خواندن پیامک لازم است.");return;}
  if(!scanLock.tryLock())return;
  try(Cursor cursor=c.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,new String[]{"address","body","date","date_sent",Telephony.Sms.SUBSCRIPTION_ID},null,null,"date DESC")){
   if(cursor==null)throw new java.io.IOException("صندوق پیامک در دسترس نیست");
   boolean full=android.os.SystemClock.elapsedRealtime()-lastFullScan>=60000||lastFullScan==0;java.util.HashMap<String,Integer> counts=new java.util.HashMap<>();int eligible=0;int count=0;while((full||count<50)&&cursor.moveToNext()){count++;String sender=cursor.getString(0),body=cursor.getString(1);long timestamp=cursor.getLong(3);if(timestamp<=0)timestamp=cursor.getLong(2);if(sender==null)sender="unknown";String normalized=sender.replaceAll("[^0-9A-Za-z]","");int used=counts.getOrDefault(normalized,0);if(used>=500)continue;counts.put(normalized,used+1);if(body==null||body.isEmpty())continue;eligible++;enqueue(c,sender,body,timestamp,false,cursor.isNull(4)?-1:cursor.getInt(4));}
   if(full){lastFullScan=android.os.SystemClock.elapsedRealtime();ReceiveStatus.record(c,"history","پایان بررسی تاریخچه: "+eligible+" پیام دریافتی موجود؛ حداکثر ۵۰۰ برای هر شماره");}
  }finally{scanLock.unlock();}
 }
}
