package ir.privateinbox.sms;
import android.content.Context;import org.json.*;import java.io.*;
final class Outbox {
 static final java.util.concurrent.CopyOnWriteArrayList<Runnable> observers=new java.util.concurrent.CopyOnWriteArrayList<>();
 static void add(Context c,String site,String key,String route,JSONObject body)throws Exception{
  add(c,site,key,route,body,false);
 }
 static void add(Context c,String site,String key,String route,JSONObject body,boolean live)throws Exception{
  JSONObject envelope=new JSONObject().put("site",site).put("key",key).put("route",route).put("body",body);
  synchronized(Store.class){File f=new File(Store.queue(c),(route.equals("server/result")?"0-result-":live?"0-live-":"1-")+java.util.UUID.randomUUID()+".sms");try(OutputStream out=Store.encrypted(c,f).openFileOutput()){out.write(envelope.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));}}UploadWorker.schedule(c);
 }
 static JSONObject read(Context c,File f)throws Exception{synchronized(Store.class){try(InputStream in=Store.encrypted(c,f).openFileInput();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[2048];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return new JSONObject(out.toString("UTF-8"));}}}
 static void isolate(Context c,File f,String reason)throws Exception{File retired=new File(c.getNoBackupFilesDir(),"retired-queue");if(!retired.exists()&&!retired.mkdirs())throw new IOException("Cannot preserve rejected queue item");if(!f.renameTo(new File(retired,f.getName())))throw new IOException("Cannot isolate rejected queue item");ReceiveStatus.record(c,"error",reason+"؛ داده در گوشی حفظ شد و صف ادامه یافت.");}
 static int count(Context c){File[] fs=Store.queue(c).listFiles((d,n)->n.endsWith(".sms"));return fs==null?0:fs.length;}
 private static String ack(String site,String key,String event)throws Exception{return "incoming_ack_"+Gateway.hash(site+"|"+key+"|"+event);}
 private static java.util.Set<String> reconcile(Context c,File[] files)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);String site=null,key=null;
  java.util.LinkedHashMap<String,java.util.List<File>> pending=new java.util.LinkedHashMap<>();
  java.util.Set<String> missing=new java.util.HashSet<>();int inspected=0;
  for(File f:files){if(++inspected>200)break;JSONObject e;
   try{e=read(c,f);}catch(Exception bad){continue;}
   if(!"server/incoming".equals(e.getString("route")))continue;
   if(site==null){site=e.getString("site");key=e.getString("key");}
   if(!site.equals(e.getString("site"))||!key.equals(e.getString("key")))continue;
   String event=e.getJSONObject("body").getString("event_id"),a=ack(site,key,event);
   if(p.getBoolean(a,false)){if(!f.delete())throw new IOException("Cannot remove confirmed duplicate");continue;}
   if(!pending.containsKey(event)&&pending.size()>=100)break;
   pending.computeIfAbsent(event,k->new java.util.ArrayList<>()).add(f);
  }
  if(pending.isEmpty())return missing;
  JSONObject response;try{response=Network.call(site,key,"server/incoming_lookup",new JSONObject().put("event_ids",new JSONArray(pending.keySet())));}
  catch(Network.HttpError error){boolean old=!site.equals(p.getString("site",""))||!key.equals(p.getString("key",""));if(old&&(error.code==401||error.code==403)){for(java.util.List<File> group:pending.values())for(File f:group)isolate(c,f,"کلید مقصد قبلی معتبر نیست");return missing;}throw error;}
  JSONArray present=response.optJSONArray("present");if(present==null)throw new IOException("Invalid reconciliation response");
  java.util.Set<String> known=new java.util.HashSet<>();for(int i=0;i<present.length();i++){String event=present.getString(i);if(!pending.containsKey(event))throw new IOException("Unexpected reconciliation ID");known.add(event);}
  android.content.SharedPreferences.Editor edit=p.edit();for(String event:known)edit.putBoolean(ack(site,key,event),true);
  if(!known.isEmpty()&&!edit.commit())throw new IOException("Cannot save server confirmation");
  for(java.util.Map.Entry<String,java.util.List<File>> item:pending.entrySet()){
   if(known.contains(item.getKey())){for(File f:item.getValue())if(!f.delete())throw new IOException("Cannot remove server-confirmed duplicate");}
   else missing.add(ack(site,key,item.getKey()));
  }
  if(!known.isEmpty()){ReceiveStatus.record(c,"error","تطبیق با وردپرس: "+known.size()+" پیام موجود، بدون بازانتقال از صف حذف شد.");for(Runnable observer:observers)observer.run();}
  return missing;
 }
 static synchronized void flush(Context c)throws Exception{
  File[] fs=Store.queue(c).listFiles((d,n)->n.endsWith(".sms"));if(fs==null)return;java.util.Arrays.sort(fs,java.util.Comparator.<File,Integer>comparing(f->f.getName().startsWith("0-live-")?1:f.getName().startsWith("0-")?0:2).thenComparingLong(File::lastModified));if(!Store.prefs(c).getBoolean("enabled",false))return;
  java.util.Set<String> missing;try{missing=reconcile(c,fs);}catch(Exception e){ReceiveStatus.record(c,"error","تطبیق صف ناموفق؛ پیام‌ها حفظ شدند: "+e.getMessage());throw e;}int count=0;
  for(File f:fs){if(!f.exists())continue;if(count>=5)return;if(!Store.prefs(c).getBoolean("enabled",false))return;JSONObject e;
   try{e=read(c,f);e.getString("site");e.getString("key");e.getString("route");e.getJSONObject("body");}catch(Exception bad){isolate(c,f,"یک رکورد صف خوانده نشد");continue;}
   String acknowledgement=null;
   if(e.getString("route").equals("server/incoming")){
    acknowledgement=ack(e.getString("site"),e.getString("key"),e.getJSONObject("body").getString("event_id"));
    if(Store.prefs(c).getBoolean(acknowledgement,false)){if(!f.delete())throw new IOException("Delete acknowledged duplicate failed");continue;}
    if(!missing.contains(acknowledgement))continue;
   }
   count++;try{Network.call(e.getString("site"),e.getString("key"),e.getString("route"),e.getJSONObject("body"));}
   catch(Network.HttpError error){android.content.SharedPreferences current=Store.prefs(c);boolean old=!e.getString("site").equals(current.getString("site",""))||!e.getString("key").equals(current.getString("key",""));String route=e.getString("route");
    boolean rejected=error.code==400||error.code==410||error.code==413||error.code==422||(error.code==404&&route.equals("server/result"));
    if((old&&(error.code==401||error.code==403))||rejected){isolate(c,f,"رکورد انتقال رد شد: HTTP "+error.code);continue;}
    ReceiveStatus.record(c,"error",error.getMessage());throw error;
   }catch(Exception error){ReceiveStatus.record(c,"error","اتصال انتقال ناموفق: "+error.getMessage());throw error;}
   if(acknowledgement!=null&&!Store.prefs(c).edit().putBoolean(acknowledgement,true).commit())throw new IOException("Acknowledgement save failed");
   if(e.getString("route").equals("server/incoming")){ReceiveStatus.record(c,"uploaded",ReceiveStatus.now());ReceiveStatus.record(c,"error","آخرین دریافت به وردپرس منتقل شد.");}
   if(!f.delete())throw new IOException("Delete failed");for(Runnable observer:observers)observer.run();
  }
 }
}
