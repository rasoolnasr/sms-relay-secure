package ir.privateinbox.sms;
import java.security.*;import java.util.*;
public class PairCryptoTest {
 static int tests;static void check(boolean b,String s){if(!b)throw new AssertionError(s);System.out.println("PASS "+s);tests++;}
 interface Attempt{void run()throws Exception;}static void reject(Attempt a,String s)throws Exception{try{a.run();throw new AssertionError(s);}catch(AssertionError e){throw e;}catch(Exception e){tests++;System.out.println("PASS "+s);}}
 public static void main(String[] x)throws Exception{
  KeyPair server=PairCrypto.generate(),client=PairCrypto.generate(),attacker=PairCrypto.generate();String secret=EnvelopeCrypto.generate();String context="pair1|https://example.test|session|"+PairCrypto.publicKey(server)+"|"+PairCrypto.publicKey(client);
  byte[] a=PairCrypto.shared(server,PairCrypto.publicKey(client),secret,context),b=PairCrypto.shared(client,PairCrypto.publicKey(server),secret,context);
  check(Arrays.equals(a,b),"Two peers derive identical pairing key");String proof=EnvelopeCrypto.seal(b,context+"|join","trusted client");check(EnvelopeCrypto.open(a,context+"|join",proof).equals("trusted client"),"Authenticated join proof opens");
  byte[] wrong=PairCrypto.shared(server,PairCrypto.publicKey(client),EnvelopeCrypto.generate(),context);reject(()->EnvelopeCrypto.open(wrong,context+"|join",proof),"Relay cannot forge proof without QR secret");
  byte[] substitute=PairCrypto.shared(server,PairCrypto.publicKey(attacker),secret,context);reject(()->EnvelopeCrypto.open(substitute,context+"|join",proof),"Replacing client public key fails");
  String credentials=EnvelopeCrypto.seal(a,context+"|credentials","master secret");check(EnvelopeCrypto.open(b,context+"|credentials",credentials).equals("master secret"),"Credentials decrypt only at paired client");reject(()->EnvelopeCrypto.open(a,context+"|credentials",proof),"Join proof cannot substitute credentials");
  reject(()->EnvelopeCrypto.open(a,context+"|other-session",credentials),"Cross-session ciphertext rejected");reject(()->PairCrypto.shared(server,"AAAA",secret,context),"Malformed public key rejected");
  KeyPairGenerator gen=KeyPairGenerator.getInstance("EC");gen.initialize(new java.security.spec.ECGenParameterSpec("secp384r1"));KeyPair bad=gen.generateKeyPair();reject(()->PairCrypto.shared(server,PairCrypto.publicKey(bad),secret,context),"Wrong curve rejected");
  check(!Arrays.equals(a,PairCrypto.shared(server,PairCrypto.publicKey(client),secret,context+"other")),"Pairing context changes derived key");
  System.out.println(tests+" pairing crypto checks passed.");
 }
}
