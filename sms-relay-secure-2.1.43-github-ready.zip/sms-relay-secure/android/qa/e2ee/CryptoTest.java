package ir.privateinbox.sms;
import java.util.*;import javax.crypto.*;import javax.crypto.spec.*;
public class CryptoTest {
 static int tests;static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);tests++;System.out.println("PASS "+msg);}
 interface Action{void run()throws Exception;}static void rejects(Action a,String msg)throws Exception{try{a.run();throw new AssertionError(msg);}catch(AssertionError e){throw e;}catch(Exception ok){tests++;System.out.println("PASS "+msg);}}
 public static void main(String[] args)throws Exception{
  byte[] k=EnvelopeCrypto.key(EnvelopeCrypto.generate()),other=EnvelopeCrypto.key(EnvelopeCrypto.generate());String p="https://example.test|incoming",message="سلام — +989123456789 — Private contact — ۱۲۳۴";
  String x=EnvelopeCrypto.seal(k,p,message);check(EnvelopeCrypto.open(k,p,x).equals(message),"Unicode round trip");check(!x.contains("989123456789")&&!x.contains("Private contact"),"No plaintext content in envelope");
  rejects(()->EnvelopeCrypto.open(other,p,x),"Wrong key rejected");rejects(()->EnvelopeCrypto.open(k,"https://example.test|send",x),"Cross-purpose substitution rejected");rejects(()->EnvelopeCrypto.open(k,"https://other.test|incoming",x),"Cross-site substitution rejected");
  byte[] raw=Base64.getDecoder().decode(x.substring(6));raw[raw.length-1]^=1;String altered="e2ee1:"+Base64.getEncoder().encodeToString(raw);rejects(()->EnvelopeCrypto.open(k,p,altered),"Modified authentication tag rejected");
  rejects(()->EnvelopeCrypto.open(k,p,message),"Plaintext fallback rejected");rejects(()->EnvelopeCrypto.open(k,p,"e2ee1:AAAA"),"Truncated envelope rejected");rejects(()->EnvelopeCrypto.key("short"),"Invalid key rejected");
  Set<String> nonces=new HashSet<>();for(int i=0;i<1000;i++){byte[] b=Base64.getDecoder().decode(EnvelopeCrypto.seal(k,p,message).substring(6));nonces.add(Base64.getEncoder().encodeToString(Arrays.copyOf(b,12)));}check(nonces.size()==1000,"Unique random nonces across 1000 encryptions");
  check(EnvelopeCrypto.peer(k,"+1 (226) 961-8770").equals(EnvelopeCrypto.peer(k,"12269618770")),"Canonical phone blind index");check(!EnvelopeCrypto.peer(k,"12269618770").equals(EnvelopeCrypto.peer(other,"12269618770")),"Blind index differs by secret key");
  check(!Arrays.equals(EnvelopeCrypto.derived(k,"index"),EnvelopeCrypto.derived(k,"encryption")),"Separate encryption and indexing subkeys");
  // Standard NIST SP 800-38D empty-input AES-256-GCM vector; validates provider/tag.
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(new byte[32],"AES"),new GCMParameterSpec(128,new byte[12]));check(EnvelopeCrypto.hex(c.doFinal(new byte[0])).equals("530f8afbc74536b9a963b4f1c4cb738b"),"AES-256-GCM NIST known-answer vector");
  System.out.println(tests+" checks passed; this is not a penetration test.");
 }
}
