package ir.privateinbox.sms;class BridgeApp{static android.content.Context context=new android.content.Context();}
