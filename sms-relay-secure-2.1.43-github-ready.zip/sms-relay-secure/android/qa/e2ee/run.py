import os,pathlib,subprocess,tempfile
root=pathlib.Path(__file__).resolve().parent
java=root.parents[1]/"app/src/main/java/ir/privateinbox/sms"
jdk=pathlib.Path(os.environ["JAVA_HOME"])/"bin"
jsonjar=pathlib.Path(os.environ["JSON_JAR"])
with tempfile.TemporaryDirectory() as tmp:
 sources=[*root.glob("*Test.java"),*root.joinpath("fixtures").rglob("*.java"),java/"EnvelopeCrypto.java",java/"E2ee.java",java/"PairCrypto.java"]
 subprocess.run([str(jdk/"javac"),"-cp",str(jsonjar),"-d",tmp,*map(str,sources)],check=True)
 for test in ["CryptoTest","CodecTest","PairCryptoTest"]:
  subprocess.run([str(jdk/"java"),"-cp",tmp+os.pathsep+str(jsonjar),"ir.privateinbox.sms."+test],check=True)
