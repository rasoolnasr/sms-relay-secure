<?php
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
global $wpdb;
foreach(['devices','messages','commands','reads','receipts','presence'] as $t)$wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'msib_'.$t);
wp_clear_scheduled_hook('msib_cleanup');

delete_option('msib_schema');

// Remove device metadata, caches and sessions created by this plugin only.
$names=$wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'msib\_%' OR option_name LIKE '\_transient\_msib\_%' OR option_name LIKE '\_transient\_timeout\_msib\_%'");
foreach($names as $name)delete_option($name);
