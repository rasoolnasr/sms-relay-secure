"""Run real client-alert logic against a deterministic fake Android notification service.
This checks polling, permission failures, retries and deduplication, not physical sound.
Usage: JAVA_HOME=/path/to/jdk python qa/alerts/run.py
"""
import os, pathlib, subprocess, tempfile, shutil
source = pathlib.Path(__file__).resolve().parents[2] / 'app/src/main/java/ir/privateinbox/sms'
files = {
'android/content/SharedPreferences.java': '''package android.content;import java.util.*;public class SharedPreferences{Map<String,Object> m=new HashMap<>();public boolean getBoolean(String k,boolean d){return (boolean)m.getOrDefault(k,d);}public String getString(String k,String d){return (String)m.getOrDefault(k,d);}public long getLong(String k,long d){return ((Number)m.getOrDefault(k,d)).longValue();}public int getInt(String k,int d){return ((Number)m.getOrDefault(k,d)).intValue();}public Editor edit(){return new Editor();}public class Editor{Map<String,Object> change=new HashMap<>();public Editor putBoolean(String k,boolean v){change.put(k,v);return this;}public Editor putString(String k,String v){change.put(k,v);return this;}public Editor putLong(String k,long v){change.put(k,v);return this;}public Editor putInt(String k,int v){change.put(k,v);return this;}public boolean commit(){m.putAll(change);return true;}public void apply(){commit();}}}''',
'android/content/Context.java': '''package android.content;public class Context{public SharedPreferences prefs=new SharedPreferences();public android.app.NotificationManager nm=new android.app.NotificationManager();public android.media.AudioManager audio=new android.media.AudioManager();public int permission=0;public int checkSelfPermission(String s){return permission;}public <T>T getSystemService(Class<T> cls){return cls.cast(cls==android.app.NotificationManager.class?nm:audio);}}''',
'android/content/Intent.java': '''package android.content;public class Intent{public static final int FLAG_ACTIVITY_CLEAR_TOP=1,FLAG_ACTIVITY_SINGLE_TOP=2;public Intent(Context c,Class<?> cls){}public Intent(String s){}public Intent addFlags(int f){return this;}public Intent putExtra(String k,String v){return this;}}''',
'android/content/pm/PackageManager.java':'package android.content.pm;public class PackageManager{public static final int PERMISSION_GRANTED=0;}',
'android/Manifest.java':'package android;public class Manifest{public static class permission{public static final String POST_NOTIFICATIONS="notify";}}',
'android/os/Build.java':'package android.os;public class Build{public static class VERSION{public static int SDK_INT=35;}}',
'android/app/Activity.java':'package android.app;public class Activity extends android.content.Context{public String getPackageName(){return "test";}public void startActivity(android.content.Intent i){}}',
'android/app/NotificationChannel.java':'''package android.app;public class NotificationChannel{public int importance;public Object sound;public NotificationChannel(String id,String name,int imp){importance=imp;}public void enableVibration(boolean b){}public void enableLights(boolean b){}public void setShowBadge(boolean b){}public void setSound(Object s,android.media.AudioAttributes a){sound=s;}public int getImportance(){return importance;}public Object getSound(){return sound;}}''',
'android/app/NotificationManager.java':'''package android.app;public class NotificationManager{public static final int IMPORTANCE_NONE=0,IMPORTANCE_DEFAULT=3,IMPORTANCE_HIGH=4,INTERRUPTION_FILTER_ALL=1;public boolean enabled=true,fail=false;public int sent=0,filter=1;public NotificationChannel channel;public void createNotificationChannel(NotificationChannel c){if(channel==null)channel=c;}public NotificationChannel getNotificationChannel(String s){return channel;}public boolean areNotificationsEnabled(){return enabled;}public int getCurrentInterruptionFilter(){return filter;}public void notify(String t,int id,Notification n){if(fail)throw new IllegalStateException("test failure");sent++;}}''',
'android/app/PendingIntent.java':'package android.app;public class PendingIntent{public static final int FLAG_UPDATE_CURRENT=1,FLAG_IMMUTABLE=2;public static PendingIntent getActivity(android.content.Context c,int id,android.content.Intent i,int flags){return new PendingIntent();}}',
'android/app/Notification.java':'''package android.app;public class Notification{public static final String CATEGORY_MESSAGE="message";public static final int VISIBILITY_PRIVATE=0;public static class BigTextStyle{public BigTextStyle bigText(String s){return this;}}public static class Builder{public Builder(android.content.Context c,String channel){}public Builder setSmallIcon(int i){return this;}public Builder setContentTitle(String s){return this;}public Builder setContentText(String s){return this;}public Builder setStyle(BigTextStyle s){return this;}public Builder setCategory(String s){return this;}public Builder setVisibility(int i){return this;}public Builder setContentIntent(PendingIntent p){return this;}public Builder setAutoCancel(boolean b){return this;}public Builder setShowWhen(boolean b){return this;}public Builder setWhen(long n){return this;}public Notification build(){return new Notification();}}}''',
'android/media/AudioAttributes.java':'package android.media;public class AudioAttributes{public static final int USAGE_NOTIFICATION=1,CONTENT_TYPE_SONIFICATION=2;public static class Builder{public Builder setUsage(int u){return this;}public Builder setContentType(int t){return this;}public AudioAttributes build(){return new AudioAttributes();}}}',
'android/media/AudioManager.java':'package android.media;public class AudioManager{public static final int RINGER_MODE_NORMAL=2,STREAM_NOTIFICATION=5;public int mode=2,volume=5;public int getRingerMode(){return mode;}public int getStreamVolume(int i){return volume;}}',
'android/provider/Settings.java':'package android.provider;public class Settings{public static final String ACTION_CHANNEL_NOTIFICATION_SETTINGS="channel",EXTRA_APP_PACKAGE="package",EXTRA_CHANNEL_ID="id";public static class System{public static final Object DEFAULT_NOTIFICATION_URI=new Object();}}',
'org/json/JSONObject.java':'''package org.json;import java.util.*;public class JSONObject{Map<String,Object> m=new HashMap<>();public JSONObject put(String k,Object v){m.put(k,v);return this;}public String optString(String k){return (String)m.getOrDefault(k,"");}public long optLong(String k){return ((Number)m.getOrDefault(k,0L)).longValue();}public boolean optBoolean(String k){return (boolean)m.getOrDefault(k,false);}public JSONArray optJSONArray(String k){return (JSONArray)m.get(k);}}''',
'org/json/JSONArray.java':'''package org.json;import java.util.*;public class JSONArray{List<JSONObject> rows=new ArrayList<>();public JSONArray put(JSONObject j){rows.add(j);return this;}public int length(){return rows.size();}public JSONObject optJSONObject(int i){return rows.get(i);}}''',
'ir/privateinbox/sms/ClientReceipts.java':'package ir.privateinbox.sms;class ClientReceipts{static void ack(android.content.Context c,String site,String key,org.json.JSONArray rows){}}',
'ir/privateinbox/sms/Store.java':'package ir.privateinbox.sms;class Store{static android.content.SharedPreferences prefs(android.content.Context c){return c.prefs;}}',
'ir/privateinbox/sms/Gateway.java':'package ir.privateinbox.sms;class Gateway{static String hash(String s){return s;}}',
'ir/privateinbox/sms/MainActivity.java':'package ir.privateinbox.sms;class MainActivity{}',
'ir/privateinbox/sms/R.java':'package ir.privateinbox.sms;class R{static class drawable{static final int ic_inbox=1;}}',
'ir/privateinbox/sms/Network.java':'''package ir.privateinbox.sms;import org.json.*;class Network{static JSONObject[] pages;static boolean fail=false;static JSONObject call(String site,String key,String path,JSONObject body)throws Exception{if(fail)throw new Exception("offline");if(!path.startsWith("client/feed?page="))throw new AssertionError(path);int page=Integer.parseInt(path.substring(path.indexOf('=')+1));return pages[page];}}''',
'ir/privateinbox/sms/Test.java':'''package ir.privateinbox.sms;
import android.content.*;import org.json.*;
public class Test{
 static int checks;static void check(boolean b,String name){if(!b)throw new AssertionError(name);System.out.println("PASS "+name);checks++;}
 static JSONObject row(long id,String direction){return new JSONObject().put("id",id).put("direction",direction).put("peer","+12260000000").put("peer_name","رضا").put("message","سلام");}
 static JSONObject feed(boolean more,JSONObject... rows){JSONArray a=new JSONArray();for(JSONObject row:rows)a.put(row);return new JSONObject().put("items",a).put("has_more",more);}
 static String marker(Context c){return "alerts_"+c.prefs.getString("site","")+"|"+c.prefs.getString("key","");}
 public static void main(String[] args)throws Exception{
  Context c=new Context();c.prefs.edit().putBoolean("enabled",true).putString("role","client").putString("site","site").putString("key","key").commit();
  Network.pages=new JSONObject[]{feed(false,row(10,"in"),row(11,"out"))};ClientAlerts.tick(c);
  check(c.nm.sent==0&&c.prefs.getLong(marker(c),-1)==10,"first sync establishes baseline without alarming old history");
  Network.pages=new JSONObject[]{feed(false,row(12,"in"),row(11,"out"),row(10,"in"))};ClientAlerts.tick(c);
  check(c.nm.sent==1&&c.prefs.getInt("arrival_count",0)==1,"new incoming produces Android notification and visible client arrival");
  check(c.prefs.getString("arrival_title","").equals("رضا"),"arrival carries contact name");
  ClientAlerts.tick(c);check(c.nm.sent==1&&c.prefs.getInt("arrival_count",0)==1,"repeat poll does not repeat sound or banner count");
  c.permission=-1;Network.pages=new JSONObject[]{feed(false,row(14,"in"),row(13,"in"),row(12,"in"))};ClientAlerts.tick(c);
  check(c.nm.sent==1&&c.prefs.getLong(marker(c),-1)==12,"denied notification permission does not advance alert checkpoint");
  check(c.prefs.getInt("arrival_count",0)==3,"permission denial still shows both arrivals inside client");
  ClientAlerts.tick(c);check(c.prefs.getInt("arrival_count",0)==3,"permission retries do not duplicate visible arrival count");
  c.permission=0;ClientAlerts.tick(c);check(c.nm.sent==3&&c.prefs.getLong(marker(c),-1)==14,"permission recovery delivers missing notifications once");
  c.nm.fail=true;Network.pages=new JSONObject[]{feed(false,row(16,"in"))};ClientAlerts.tick(c);check(c.prefs.getLong(marker(c),-1)==14,"notification exception preserves retry checkpoint");
  c.nm.fail=false;ClientAlerts.tick(c);check(c.nm.sent==4&&c.prefs.getInt("arrival_count",0)==4,"notification recovery does not duplicate banner");
  c.nm.channel.importance=0;Network.pages=new JSONObject[]{feed(false,row(17,"in"))};ClientAlerts.tick(c);check(c.prefs.getLong(marker(c),-1)==16&&!MessageAlerts.warning(c).isEmpty(),"blocked channel is visible and not treated as delivered");
  c.nm.channel.importance=4;ClientAlerts.tick(c);check(c.nm.sent==5,"unblocking channel delivers pending notification");
  Network.pages=new JSONObject[]{feed(true,row(20,"in")),feed(false,row(19,"in"),row(18,"out"))};ClientAlerts.tick(c);check(c.nm.sent==7,"multiple pages alert incoming only");
  Network.fail=true;boolean failed=false;try{ClientAlerts.tick(c);}catch(Exception e){failed=true;}Network.fail=false;check(failed&&c.prefs.getLong(marker(c),-1)==20,"offline poll preserves checkpoint");
  int count=c.prefs.getInt("arrival_count",0);MessageAlerts.show(c,"test_unique","","آزمایش","test");check(c.prefs.getInt("arrival_count",0)==count,"test notification does not alter real message arrival count");
  c.prefs.edit().putString("key","different").commit();MessageAlerts.show(c,"different-token","number","name","text");check(c.prefs.getInt("arrival_count",0)==1&&c.prefs.getString("arrival_scope","").equals("site|different"),"arrival banner state is isolated between connected accounts");
  c.nm.channel.sound=null;check(!MessageAlerts.warning(c).isEmpty(),"silent channel reports actionable warning");
  System.out.println(checks+" alert checks passed");
 }
}'''
}
# Extend the same fake service to verify SIM targeting and partial send retries.
files['org/json/JSONObject.java'] = files['org/json/JSONObject.java'].replace('public JSONArray optJSONArray', 'public String getString(String k){return optString(k);}public int getInt(String k){return (int)optLong(k);}public JSONArray getJSONArray(String k){return (JSONArray)m.get(k);}public JSONArray optJSONArray')
files['org/json/JSONArray.java'] = files['org/json/JSONArray.java'].replace('public JSONObject optJSONObject', 'public JSONObject getJSONObject(int i){return rows.get(i);}public JSONObject optJSONObject')
files['ir/privateinbox/sms/Network.java'] = files['ir/privateinbox/sms/Network.java'].replace('static boolean fail=false;', 'static boolean fail=false;static int sendCalls=0,failSim=-1;static boolean loseResponse=false;static java.util.Set<String> accepted=new java.util.HashSet<>();static java.util.List<Integer> subscriptions=new java.util.ArrayList<>();').replace('if(fail)throw', 'if(path.endsWith("/send")){sendCalls++;int sim=body.getInt("sim_id");subscriptions.add(sim);if(sim==failSim&&!loseResponse){failSim=-1;throw new Exception("offline");}accepted.add(body.getString("event_id"));if(sim==failSim){failSim=-1;throw new Exception("lost response");}return new JSONObject();}if(fail)throw')
files['ir/privateinbox/sms/Test.java'] = files['ir/privateinbox/sms/Test.java'].replace('System.out.println(checks+" alert checks passed");', '''
  JSONObject plan=SendPlan.prepare(null,"+12260000000","test",java.util.Arrays.asList(101,202));
  check(plan.getJSONArray("requests").length()==2&&!plan.getJSONArray("requests").getJSONObject(0).getString("event_id").equals(plan.getJSONArray("requests").getJSONObject(1).getString("event_id")),"both SIMs create separate stable event IDs");
  Network.failSim=202;boolean partial=false;try{SendPlan.submit(plan,"site","key","server",saved->{});}catch(Exception e){partial=true;}
  check(partial&&SendPlan.acknowledged(plan)==1&&Network.accepted.size()==1,"second SIM failure preserves first acknowledgement");
  SendPlan.submit(plan,"site","key","server",saved->{});
  check(Network.sendCalls==3&&Network.accepted.size()==2&&Network.subscriptions.equals(java.util.Arrays.asList(101,202,202)),"retry skips acknowledged first SIM");
  check(SendPlan.prepare(plan,"+12260000000","test",java.util.Arrays.asList(101,202))==plan,"matching draft retains per-SIM event identities");
  JSONObject single=SendPlan.prepare(null,"+12260000000","one",java.util.Arrays.asList(202,202));check(single.getJSONArray("requests").length()==1,"one active SIM creates one request and duplicate IDs are excluded");
  JSONObject lost=SendPlan.prepare(null,"+12260000000","lost",java.util.Arrays.asList(101,202));Network.failSim=101;Network.loseResponse=true;try{SendPlan.submit(lost,"site","key","server",saved->{});}catch(Exception expected){}
  String stable=lost.getJSONArray("requests").getJSONObject(0).getString("event_id");int before=Network.accepted.size();SendPlan.submit(lost,"site","key","server",saved->{});
  check(Network.accepted.size()==before+1&&stable.equals(lost.getJSONArray("requests").getJSONObject(0).getString("event_id")),"lost HTTP response retries same ID for server deduplication");
  boolean empty=false;try{SendPlan.prepare(null,"n","t",java.util.List.of());}catch(IllegalArgumentException e){empty=true;}check(empty,"sending without active SIM is rejected");
  System.out.println(checks+" alert and SIM-send checks passed");
''')
files['org/json/JSONObject.java'] = files['org/json/JSONObject.java'].replace('public String getString', 'public int optInt(String k,int fallback){return ((Number)m.getOrDefault(k,fallback)).intValue();}public int optInt(String k){return optInt(k,0);}public String getString')
files['ir/privateinbox/sms/Test.java'] = files['ir/privateinbox/sms/Test.java'].replace('System.out.println(checks+" alert and SIM-send checks passed");', '''
  JSONArray sims=new JSONArray().put(new JSONObject().put("slot",1).put("id",202)).put(new JSONObject().put("slot",0).put("id",101));
  check(SmsRouting.active(sims).equals(java.util.Arrays.asList(101,202)),"SIM choices use real subscription IDs in physical slot order");
  check(SmsRouting.resolve(sims,202).equals(java.util.List.of(202)),"server SIM 2 selection routes only through SIM 2");
  check(SmsRouting.resolve(sims,-3).equals(java.util.Arrays.asList(101,202)),"server both selection routes one dispatch through each active SIM");
  JSONArray one=new JSONArray().put(new JSONObject().put("slot",1).put("id",202));check(SmsRouting.active(one).size()==1&&SmsRouting.resolve(one,-1).equals(java.util.List.of(202)),"single active SIM has only that subscription, even in second slot");
  boolean bothMissing=false;try{SmsRouting.resolve(one,-3);}catch(IllegalArgumentException e){bothMissing=true;}check(bothMissing,"removed second SIM never falls back silently for both policy");
  boolean selectedMissing=false;try{SmsRouting.resolve(one,101);}catch(IllegalArgumentException e){selectedMissing=true;}check(selectedMissing,"removed selected SIM cannot reroute to another SIM");
  System.out.println(checks+" alert and SIM-send checks passed");
''')
with tempfile.TemporaryDirectory() as temp:
 root=pathlib.Path(temp)
 for name,text in files.items():
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 for name in ['ClientAlerts.java','MessageAlerts.java','SendPlan.java','SmsRouting.java']:shutil.copy(source/name,root/'ir/privateinbox/sms'/name)
 javac=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javac') if os.environ.get('JAVA_HOME') else 'javac'
 java=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/java') if os.environ.get('JAVA_HOME') else 'java'
 subprocess.run([javac,'-d',str(root/'classes'),*[str(p) for p in root.rglob('*.java')]],check=True)
 subprocess.run([java,'-cp',str(root/'classes'),'ir.privateinbox.sms.Test'],check=True)
