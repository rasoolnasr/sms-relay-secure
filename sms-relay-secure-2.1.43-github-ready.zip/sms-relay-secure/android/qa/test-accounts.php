<?php
// In-memory SQL contract tests. These are not live WordPress/MySQL integration tests.
define('ABSPATH',__DIR__);define('ARRAY_A',1);
class WP_Error {public $code,$data;function __construct($code,$message='',$data=[]){$this->code=$code;$this->data=$data;}}
function is_wp_error($x){return $x instanceof WP_Error;}
$ssl=true;$opts=['srs_customer_signup'=>'1'];$mail=[];$mail_ok=true;
function is_ssl(){global $ssl;return $ssl;}function is_email($x){return filter_var($x,FILTER_VALIDATE_EMAIL);}
function wp_salt($x){return 'test-salt-only';}function sanitize_text_field($x){return strip_tags($x);}function add_shortcode(){}
function get_option($k,$default=false){global $opts;return $opts[$k]??$default;}function update_option($k,$v){global $opts;$opts[$k]=$v;return true;}
function wp_mail($to,$subject,$text){global $mail,$mail_ok;$mail[]=[$to,$text];return $mail_ok;}
class SRS_Billing {static function ready(){return false;}static function account_id($id){return hash('sha256',(string)$id);}static function entitled($a){return (int)$a['trial_until']>=time();}}
class SRS_Bridge {
 static function table($x){return 'wp_srs_'.$x;}static function enc($x){return base64_encode(json_encode($x));}
 static function erase_device($id){global $wpdb;if($wpdb->fail_erase)return new WP_Error('delete_failed');$wpdb->delete('wp_srs_devices',['id'=>$id]);$wpdb->delete('wp_srs_account_devices',['device_id'=>$id]);return ['ok'=>true];}
}
class DB {
 public $rows=[],$last_error='',$insert_id=0,$fail_erase=false,$fail_cas=false,$fail_lock=false;
 private $next=0;
 function prepare($sql,...$a){return [$sql,$a];}
 function insert($table,$r){
  if($table==='wp_srs_accounts'||$table==='wp_srs_devices'){$r['id']=++$this->next;$this->insert_id=$r['id'];}
  if($table==='wp_srs_accounts')foreach($this->rows[$table]??[] as $old)if($old['email']===$r['email'])return false;
  if($table==='wp_srs_devices')foreach($this->rows[$table]??[] as $old)if($old['server_hash']===$r['server_hash']||$old['client_hash']===$r['client_hash'])return false;
  if($table==='wp_srs_account_devices')foreach($this->rows[$table]??[] as $old)if($old['device_id']===$r['device_id']||($old['account_id']===$r['account_id']&&$old['install_hash']===$r['install_hash']))return false;
  $this->rows[$table][]=$r;return 1;
 }
 function matches($r,$where){foreach($where as $k=>$v)if((string)($r[$k]??null)!==(string)$v)return false;return true;}
 function delete($table,$where){$n=0;foreach($this->rows[$table]??[] as $k=>$r)if($this->matches($r,$where)){unset($this->rows[$table][$k]);$n++;}return $n;}
 function update($table,$data,$where){$n=0;foreach($this->rows[$table]??[] as $k=>$r)if($this->matches($r,$where)){$this->rows[$table][$k]=array_merge($r,$data);$n++;}return $n;}
 function query($q){[$sql,$a]=$q;
  if(strpos($sql,'INSERT INTO wp_srs_account_limits')===0){foreach($this->rows['wp_srs_account_limits']??[] as $k=>$r)if($r['bucket']===$a[0]){$this->rows['wp_srs_account_limits'][$k]['count']++;return 1;}return $this->insert('wp_srs_account_limits',['bucket'=>$a[0],'count'=>1,'expires_at'=>$a[1]]);}
  if(strpos($sql,'UPDATE wp_srs_challenges SET attempts=')===0){if($this->fail_cas){$this->fail_cas=false;return 0;}foreach($this->rows['wp_srs_challenges']??[] as $k=>$r)if($r['id']===$a[0]&&($r['attempts']??0)===$a[1]&&$r['expires_at']>=$a[2]){$this->rows['wp_srs_challenges'][$k]['attempts']=($r['attempts']??0)+1;return 1;}return 0;}
  if(strpos($sql,'DELETE FROM wp_srs_challenges')===0)return $this->delete('wp_srs_challenges',['id'=>$a[0],'attempts'=>$a[1]]);
  if(strpos($sql,'INSERT INTO wp_srs_accounts')===0){foreach($this->rows['wp_srs_accounts']??[] as $r)if($r['email']===$a[0])return 1;return $this->insert('wp_srs_accounts',['email'=>$a[0],'created_at'=>$a[1],'trial_until'=>$a[2],'state'=>'active','policy'=>$a[3]]);}
  throw new Exception('Unsupported SQL: '.$sql);
 }
 function get_row($q,$kind=null){[$sql,$a]=$q;
  if(strpos($sql,'SELECT * FROM wp_srs_challenges')===0){foreach($this->rows['wp_srs_challenges']??[] as $r)if($r['id']===$a[0])return $r+['attempts'=>0];return null;}
  if(strpos($sql,'SELECT * FROM wp_srs_accounts')===0){foreach($this->rows['wp_srs_accounts']??[] as $r)if($r['email']===$a[0])return $r;return null;}
  if(strpos($sql,'SELECT a.*,t.issued_at')===0){foreach($this->rows['wp_srs_account_tokens']??[] as $t)if($t['token_hash']===$a[0]&&$t['expires_at']>=$a[1])foreach($this->rows['wp_srs_accounts']??[] as $r)if($r['id']===$t['account_id'])return $r+['session_issued_at'=>$t['issued_at']];return null;}
  if(strpos($sql,'SELECT d.* FROM')===0){foreach($this->rows['wp_srs_account_devices']??[] as $o)if($o['account_id']===$a[0]&&$o['install_hash']===$a[1])foreach($this->rows['wp_srs_devices']??[] as $d)if($d['id']===$o['device_id'])return $d;return null;}
  if(strpos($sql,'SELECT a.id,a.state,a.trial_until')===0){foreach($this->rows['wp_srs_account_devices']??[] as $o)if($o['device_id']===$a[0])foreach($this->rows['wp_srs_accounts']??[] as $r)if($r['id']===$o['account_id'])return $r;return null;}
  throw new Exception('Unsupported row SQL: '.$sql);
 }
 function get_var($q){[$sql,$a]=$q;
  if(strpos($sql,'SELECT GET_LOCK')===0)return $this->fail_lock?0:1;
  if(strpos($sql,'SELECT RELEASE_LOCK')===0)return 1;
  if(strpos($sql,'SELECT count FROM wp_srs_account_limits')===0){foreach($this->rows['wp_srs_account_limits']??[] as $r)if($r['bucket']===$a[0])return $r['count'];return null;}
  if(strpos($sql,'SELECT state FROM wp_srs_accounts')===0){foreach($this->rows['wp_srs_accounts']??[] as $r)if($r['id']===$a[0])return $r['state'];return null;}
  if(strpos($sql,'SELECT COUNT(*) FROM wp_srs_account_devices')===0){$n=0;foreach($this->rows['wp_srs_account_devices']??[] as $r)if($r['account_id']===$a[0])$n++;return $n;}
  if(strpos($sql,'SELECT device_id FROM wp_srs_account_devices')===0){foreach($this->rows['wp_srs_account_devices']??[] as $r)if($r['account_id']===$a[0]&&$r['device_id']===$a[1])return $r['device_id'];return null;}
  throw new Exception('Unsupported scalar SQL: '.$sql);
 }
 function get_results($q,$kind=null){[$sql,$a]=$q;if(strpos($sql,'SELECT d.id,d.label')===0){$rows=[];foreach($this->rows['wp_srs_account_devices']??[] as $o)if($o['account_id']===$a[0])foreach($this->rows['wp_srs_devices']??[] as $d)if($d['id']===$o['device_id'])$rows[]=$d;return $rows;}throw new Exception('Unsupported results SQL: '.$sql);}
 function get_col($q){[$sql,$a]=$q;$rows=[];foreach($this->rows['wp_srs_account_devices']??[] as $r)if($r['account_id']===$a[0])$rows[]=$r['device_id'];return $rows;}
}
class Req {
 public $b,$p=[],$key,$route;
 function __construct($b=[],$key='',$route='start'){$this->b=$b;$this->key=$key;$this->route='/sms-relay-secure/v1/account/'.$route;}
 function get_body(){return json_encode($this->b);}function get_json_params(){return $this->b;}function get_header($n){return $this->key;}function get_route(){return $this->route;}function get_param($n){return $this->p[$n]??null;}function set_param($n,$v){$this->p[$n]=$v;}
}
$wpdb=new DB;require $argv[1];$n=0;
function check($ok,$label){global $n;if(!$ok)throw new Exception($label);$n++;echo "PASS $label\n";}
function call($name,$body=[],$token=''){$r=new Req($body,$token,$name);$gate=in_array($name,['start','verify'],true)?SRS_Accounts::public_permission($r):SRS_Accounts::auth($r);return is_wp_error($gate)?$gate:SRS_Accounts::$name($r);}
function begin($email){global $mail;$s=call('start',['email'=>$email]);preg_match('/code is: ([0-9]{6})/',$mail[count($mail)-1][1],$m);return [$s,$m[1]];}
function login($email){[$s,$code]=begin($email);return call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY]);}
function keys($x){return ['install_id'=>hash('sha256','install'.$x),'server_key'=>hash('sha256','server'.$x),'client_key'=>hash('sha256','client'.$x),'label'=>'Test phone '.$x];}
$ssl=false;check(is_wp_error(call('start',['email'=>'a@example.com'])),'HTTPS required');$ssl=true;
check(is_wp_error(call('start',['email'=>'bad'])),'Invalid email rejected');
$mail_ok=false;check(call('start',['email'=>'failure@example.com'])->code==='email_unavailable','Mail failure does not create usable challenge');$mail_ok=true;
[$s,$code]=begin('alice@example.com');check(strlen($s['challenge'])===64,'Challenge is high entropy');
check(call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>'old'])->code==='invalid','Consent version required');
check(call('verify',['challenge'=>$s['challenge'],'code'=>'999999'===$code?'000000':'999999','policy'=>SRS_Accounts::POLICY])->code==='code_invalid','Wrong code rejected');
$alice=call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY]);check($alice['ok']&&strlen($alice['token'])===64,'Correct code produces account session');
check($alice['trial_until']<=time()+259200&&$alice['trial_until']>=time()+259190,'Trial uses server time for three days');
check(is_wp_error(call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY])),'Code cannot be replayed');
check(!in_array($alice['token'],array_column($wpdb->rows['wp_srs_account_tokens'],'token_hash'),true),'Only session hash stored');
check(is_wp_error(call('status',[],str_repeat('f',64))),'Invalid session rejected');
$bob=login('bob@example.com');$a=call('bootstrap',keys('a'),$alice['token']);check($a['ok'],'Server auto-provisioned');
check(!isset($a['server_key'],$a['client_key'],$a['e2ee_key']),'Bootstrap response does not leak keys');
check(call('bootstrap',keys('a'),$alice['token'])['duplicate'],'Retry is idempotent');
$bad=keys('a');$bad['server_key']=hash('sha256','changed');check(call('bootstrap',$bad,$alice['token'])->code==='device_conflict','Existing credentials cannot be overwritten');
$b=call('bootstrap',keys('b'),$bob['token']);check($b['device_id']!==$a['device_id'],'Customers have distinct inboxes');
check(count(call('devices',[],$alice['token'])['devices'])===1,'Device listing excludes other customer');
check(call('revoke',['device_id'=>$a['device_id']],$bob['token'])->code==='not_found','Foreign device cannot be revoked');
check(call('bootstrap',keys('a2'),$alice['token'])['ok'],'Second test server allowed');
check(call('bootstrap',keys('a3'),$alice['token'])->code==='device_limit','Third test server rejected');
$wpdb->fail_lock=true;check(call('bootstrap',keys('b2'),$bob['token'])->code==='busy','Lock contention fails closed');$wpdb->fail_lock=false;
check(SRS_Accounts::device_permission($a['device_id'])===true,'Active trial allows relay');
check(call('revoke',['device_id'=>$a['device_id']],$alice['token'])['ok'],'Owner can revoke');
$wpdb->update('wp_srs_accounts',['trial_until'=>time()-1],['id'=>$bob['account_id']]);
check(SRS_Accounts::device_permission($b['device_id'])->code==='trial_expired','Expired trial blocks relay');
check(call('bootstrap',keys('b2'),$bob['token'])->code==='trial_expired','Expired trial blocks provisioning');
check(call('status',[],$bob['token'])['ok'],'Expired trial can still manage account');
check(SRS_Accounts::device_permission(9999)===true,'Legacy inbox behavior preserved');
check(call('delete',['confirm'=>'wrong'],$alice['token'])->code==='confirmation_required','Deletion requires explicit confirmation');
$wpdb->update('wp_srs_account_tokens',['issued_at'=>time()-601],['token_hash'=>hash('sha256',$alice['token'])]);check(call('delete',['confirm'=>'DELETE'],$alice['token'])->code==='recent_login_required','Deletion requires recent verified login');
$wpdb->update('wp_srs_account_tokens',['issued_at'=>time()],['token_hash'=>hash('sha256',$alice['token'])]);
$wpdb->fail_erase=true;check(call('delete',['confirm'=>'DELETE'],$alice['token'])->code==='delete_failed','Cleanup failure reported');
check(SRS_Accounts::device_permission($a['device_id'])->code==='account_unavailable','Interrupted deletion blocks all relay access');
check(call('bootstrap',keys('new'),$alice['token'])->code==='account_deleting','Deleting account cannot create devices');
$fresh=login('alice@example.com');check($fresh['account_state']==='deleting','Fresh verified session can resume a pending deletion');$alice['token']=$fresh['token'];
$wpdb->fail_erase=false;check(call('delete',['confirm'=>'DELETE'],$alice['token'])['deleted'],'Interrupted deletion can resume');
check(call('status',[],$alice['token'])->code==='unauthorized','Deleted account sessions revoked');
check(count(call('devices',[],$bob['token'])['devices'])===1,'Other account survives deletion');
$again=login('alice@example.com');check($again['trial_until']<time(),'Recreating deleted account cannot renew trial');
check(call('logout',[],$bob['token'])['ok'],'Account logout revokes its session');check(call('status',[],$bob['token'])->code==='unauthorized','Logged-out session rejected');
$opts['srs_customer_signup']='0';check(login('new@example.com')->code==='signup_unavailable','New signup disabled by default switch');check(call('start',['email'=>'alice@example.com'])->code==='rate_limit','Fourth email code in ten minutes is rate-limited');$wpdb->rows['wp_srs_account_limits']=[];check(login('alice@example.com')['ok'],'Existing accounts can login when signup disabled');
[$s,$code]=begin('guess@example.com');for($i=0;$i<5;$i++)call('verify',['challenge'=>$s['challenge'],'code'=>'999999'===$code?'000000':'999999','policy'=>SRS_Accounts::POLICY]);check(call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY])->code==='code_invalid','Five failed guesses exhaust challenge');
[$s,$code]=begin('race@example.com');$wpdb->fail_cas=true;check(call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY])->code==='code_invalid','Concurrent attempt CAS fails closed');
[$s,$code]=begin('expired@example.com');$wpdb->update('wp_srs_challenges',['expires_at'=>time()-1],['id'=>$s['challenge']]);check(call('verify',['challenge'=>$s['challenge'],'code'=>$code,'policy'=>SRS_Accounts::POLICY])->code==='code_invalid','Expired code rejected');
check(SRS_Accounts::limit('specific-test',1,600)&&!SRS_Accounts::limit('specific-test',1,600),'Rate limit enforces per-window maximum');
echo "$n account tests passed; stub database only.\n";
