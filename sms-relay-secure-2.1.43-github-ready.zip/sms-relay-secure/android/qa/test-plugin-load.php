<?php
define('ABSPATH',__DIR__.'/fake-wp/');define('ARRAY_A','ARRAY_A');
function add_action(){}function add_filter(){}function add_shortcode(){}function register_activation_hook(){}function register_deactivation_hook(){}
$routes=[];function register_rest_route($namespace,$route,$args){global $routes;$key=$namespace.$route;if(isset($routes[$key]))throw new Exception('Duplicate REST route');$routes[$key]=$args;}
require __DIR__.'/legacy/mobile-sms-inbox/mobile-sms-inbox.php';
$new=$argv[1];
require $new;
MSI_Bridge::routes();SRS_Bridge::routes();
function check($b,$s){if(!$b)throw new Exception($s);echo "PASS $s\n";}
check(class_exists('MSI_Bridge')&&class_exists('SRS_Bridge'),'Old and new plugins load together');
check(class_exists('MSI_Pairing')&&class_exists('SRS_Pairing'),'Pairing classes independent');
check(isset($routes['mobile-sms/v2/health'])&&isset($routes['sms-relay-secure/v1/health']),'Independent REST namespaces');
check(isset($routes['sms-relay-secure/v1/server/pair_create'])&&isset($routes['sms-relay-secure/v1/pair/join']),'New pairing routes registered');
class FakeDB {public $prefix='wp_';}$wpdb=new FakeDB;
check(MSI_Bridge::table('messages')==='wp_msib_messages'&&SRS_Bridge::table('messages')==='wp_srs_messages','Independent data tables');
check(MSI_Pairing::name('abc')!==SRS_Pairing::name('abc'),'Independent pairing storage');
check(SRS_Bridge::health(null)['service']==='sms-relay-secure'&&SRS_Bridge::health(null)['version']==='2.1.41','Brand and version advertised');
$source=file_get_contents($new);check(preg_match('/Plugin Name:\s*SMS Relay Secure/',$source),'Installable plugin header');
echo count($routes)." distinct routes registered; this is a simulated WordPress loader, not a live installation.\n";
