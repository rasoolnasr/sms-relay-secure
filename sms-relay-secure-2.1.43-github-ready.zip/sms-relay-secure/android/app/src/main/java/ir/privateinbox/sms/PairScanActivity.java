package ir.privateinbox.sms;
/** Keep pairing QR data off screenshots and scanner result images. */
public class PairScanActivity extends com.journeyapps.barcodescanner.CaptureActivity {
 @Override public void onCreate(android.os.Bundle state){super.onCreate(state);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);}
}
