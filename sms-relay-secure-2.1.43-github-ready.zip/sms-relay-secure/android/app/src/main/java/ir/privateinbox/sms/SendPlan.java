package ir.privateinbox.sms;
import org.json.*;import java.util.*;
/** One stable request per selected subscription, preserved across partial failures. */
final class SendPlan {
 interface Save {void save(JSONObject plan)throws Exception;}
 static JSONObject prepare(JSONObject previous,String number,String text,List<Integer> ids)throws Exception{
  if(ids.isEmpty())throw new IllegalArgumentException("سیم‌کارت فعالی انتخاب نشده است.");
  LinkedHashSet<Integer> unique=new LinkedHashSet<>(ids);for(int id:unique)if(id < -1)throw new IllegalArgumentException("سیم‌کارت انتخاب‌شده فعال نیست.");
  String signature=unique.toString();
  if(previous!=null&&number.equals(previous.optString("to"))&&text.equals(previous.optString("message"))&&signature.equals(previous.optString("targets")))return previous;
  JSONArray requests=new JSONArray();for(int id:unique)requests.put(new JSONObject().put("event_id",UUID.randomUUID().toString()).put("sim_id",id).put("ack",false));
  return new JSONObject().put("to",number).put("message",text).put("targets",signature).put("requests",requests);
 }
 static int acknowledged(JSONObject plan){int count=0;JSONArray requests=plan.optJSONArray("requests");if(requests!=null)for(int i=0;i<requests.length();i++)if(requests.optJSONObject(i).optBoolean("ack"))count++;return count;}
 static void submit(JSONObject plan,String site,String key,String role,Save save)throws Exception{
  JSONArray requests=plan.getJSONArray("requests");
  for(int i=0;i<requests.length();i++){
   JSONObject request=requests.getJSONObject(i);if(request.optBoolean("ack"))continue;
   JSONObject body=new JSONObject().put("event_id",request.getString("event_id")).put("sim_id",request.getInt("sim_id")).put("to",plan.getString("to")).put("message",plan.getString("message"));
   Network.call(site,key,role+"/send",body);
   request.put("ack",true);save.save(plan);
  }
 }
}
