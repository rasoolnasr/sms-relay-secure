package ir.privateinbox.sms;

import android.app.*;import com.android.billingclient.api.*;import java.util.*;

/** Prices and eligible offers come from Play; never grant entitlement on a client-only receipt. */
final class PlaySubscriptions implements PurchasesUpdatedListener {
 interface Listener {void message(String text);void purchase(String token);}
 private final Activity activity;private final Listener listener;private final String account;
 private final BillingClient billing;
 PlaySubscriptions(Activity activity,String account,Listener listener){
  this.activity=activity;this.listener=listener;this.account=account;
  billing=BillingClient.newBuilder(activity).setListener(this).enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().enablePrepaidPlans().build()).enableAutoServiceReconnection().build();
 }
 void connect(Runnable ready){if(billing.isReady()){ready.run();return;}billing.startConnection(new BillingClientStateListener(){public void onBillingServiceDisconnected(){listener.message("اتصال فروشگاه قطع شد؛ دوباره تلاش کنید.");}public void onBillingSetupFinished(BillingResult result){if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)ready.run();else listener.message("Google Play Billing در دسترس نیست ("+result.getResponseCode()+"). خرید فقط با نسخه نصب‌شده از فروشگاه و حساب آزمایش مجاز قابل تست است.");}});}
 void plans(){connect(()->{
  List<QueryProductDetailsParams.Product> products=new ArrayList<>();for(String id:new String[]{"sms_relay_monthly","sms_relay_yearly"})products.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.SUBS).build());
  billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build(),(result,detailsResult)->{
   if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK){listener.message("قیمت‌ها از گوگل دریافت نشد.");return;}
   List<ProductDetails> productRows=new ArrayList<>();List<ProductDetails.SubscriptionOfferDetails> offers=new ArrayList<>();List<String> labels=new ArrayList<>();
   for(ProductDetails product:detailsResult.getProductDetailsList()){List<ProductDetails.SubscriptionOfferDetails> available=product.getSubscriptionOfferDetails();if(available==null)continue;for(ProductDetails.SubscriptionOfferDetails offer:available){StringBuilder label=new StringBuilder(product.getName()).append(" — ").append(offer.getBasePlanId());for(ProductDetails.PricingPhase phase:offer.getPricingPhases().getPricingPhaseList())label.append("\n").append(phase.getFormattedPrice()).append(" / ").append(phase.getBillingPeriod()).append(phase.getBillingCycleCount()>0?" × "+phase.getBillingCycleCount():"");labels.add(label.toString());productRows.add(product);offers.add(offer);}}
   activity.runOnUiThread(()->{if(activity.isDestroyed())return;if(labels.isEmpty()){listener.message("محصول فعال و قابل خریدی برای این حساب در Google Play پیدا نشد.");return;}new AlertDialog.Builder(activity).setTitle("اشتراک — قیمت و دوره از Google Play").setItems(labels.toArray(new String[0]),(dialog,index)->{
    ProductDetails product=productRows.get(index);ProductDetails.SubscriptionOfferDetails offer=offers.get(index);
    new AlertDialog.Builder(activity).setTitle("تأیید انتخاب اشتراک").setMessage(labels.get(index)+"\n\nاشتراک طبق شرایط نمایش‌داده‌شده در Google Play تمدید می‌شود، مگر لغو کنید. حذف حساب برنامه، اشتراک Google Play را لغو نمی‌کند. هزینه پیامک اپراتور جداست.").setPositiveButton("ادامه در Google Play",(d,w)->{
     BillingFlowParams.ProductDetailsParams item=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product).setOfferToken(offer.getOfferToken()).build();
     BillingResult response=billing.launchBillingFlow(activity,BillingFlowParams.newBuilder().setObfuscatedAccountId(account).setProductDetailsParamsList(Collections.singletonList(item)).build());
     if(response.getResponseCode()!=BillingClient.BillingResponseCode.OK)listener.message("خرید شروع نشد ("+response.getResponseCode()+").");
    }).setNegativeButton("انصراف",null).show();
   }).setNegativeButton("بستن",null).show();});
  });
 });}
 void restore(){connect(()->billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),(result,purchases)->{if(result.getResponseCode()==BillingClient.BillingResponseCode.OK){if(purchases.isEmpty())listener.message("اشتراکی در حساب فعلی Google Play پیدا نشد.");for(Purchase purchase:purchases)handle(purchase);}else listener.message("بازیابی خرید انجام نشد.");}));}
 private void handle(Purchase purchase){if(purchase.getPurchaseState()==Purchase.PurchaseState.PENDING){listener.message("خرید در انتظار تکمیل پرداخت است؛ دسترسی پولی هنوز فعال نشده.");return;}if(purchase.getPurchaseState()==Purchase.PurchaseState.PURCHASED)listener.purchase(purchase.getPurchaseToken());}
 @Override public void onPurchasesUpdated(BillingResult result,List<Purchase> purchases){if(result.getResponseCode()==BillingClient.BillingResponseCode.OK&&purchases!=null){for(Purchase purchase:purchases)handle(purchase);}else if(result.getResponseCode()==BillingClient.BillingResponseCode.USER_CANCELED)listener.message("خرید لغو شد.");else listener.message("خرید تکمیل نشد ("+result.getResponseCode()+").");}
 void close(){billing.endConnection();}
}
