package ir.privateinbox.sms;
import android.content.*;import android.app.*;import android.media.*;
final class MessageAlerts {
 static final String CHANNEL="sms-arrivals-v1";
 static final java.util.concurrent.CopyOnWriteArrayList<Runnable> observers=new java.util.concurrent.CopyOnWriteArrayList<>();
 static NotificationManager manager(Context c){
  NotificationManager manager=c.getSystemService(NotificationManager.class);
  NotificationChannel channel=new NotificationChannel(CHANNEL,"پیامک جدید با صدا",NotificationManager.IMPORTANCE_HIGH);
  channel.enableVibration(true);channel.enableLights(true);channel.setShowBadge(true);
  channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
  manager.createNotificationChannel(channel);return manager;
 }
 static String warning(Context c){try{
  NotificationManager nm=manager(c);
  if(!nm.areNotificationsEnabled()||(android.os.Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED))return "اعلان پیام‌ها خاموش است؛ برای فعال‌سازی لمس کنید.";
  NotificationChannel channel=nm.getNotificationChannel(CHANNEL);
  if(channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return "اعلان پیام جدید مسدود است؛ تنظیمات را باز کنید.";
  if(channel.getImportance()<NotificationManager.IMPORTANCE_DEFAULT||channel.getSound()==null)return "صدای پیام جدید خاموش است؛ تنظیمات را باز کنید.";
  AudioManager audio=c.getSystemService(AudioManager.class);
  if(audio.getRingerMode()!=AudioManager.RINGER_MODE_NORMAL||audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION)==0)return "گوشی بی‌صداست؛ صدای اعلان را روشن کنید.";
  if(nm.getCurrentInterruptionFilter()!=NotificationManager.INTERRUPTION_FILTER_ALL)return "مزاحم نشوید فعال است؛ صدای پیام ممکن است پخش نشود.";
  return "";
 }catch(Exception e){return "بررسی اعلان انجام نشد؛ تنظیمات را باز کنید.";}}
 static void settings(Activity a){Intent i=new Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,a.getPackageName()).putExtra(android.provider.Settings.EXTRA_CHANNEL_ID,CHANNEL);manager(a);a.startActivity(i);}
 static synchronized boolean show(Context c,String token,String number,String name,String text){try{
  SharedPreferences saved=Store.prefs(c);String dedup="notice_"+Gateway.hash(token);
  if(saved.getBoolean(dedup,false))return true;
  String title=name==null||name.isEmpty()?number:name;
  // Show an in-app arrival even when Android notification permission is denied.
  if(!token.startsWith("test_")&&"client".equals(saved.getString("role",""))&&!saved.getBoolean("visual_"+Gateway.hash(token),false)){
   if(!saved.edit().putBoolean("visual_"+Gateway.hash(token),true).putString("arrival_scope",Gateway.hash(saved.getString("site","")+"|"+saved.getString("key",""))).putString("arrival_token",token).putString("arrival_title",title).putString("arrival_text",text).putInt("arrival_count",(Gateway.hash(saved.getString("site","")+"|"+saved.getString("key","")).equals(saved.getString("arrival_scope",""))?saved.getInt("arrival_count",0):0)+1).commit())return false;
   for(Runnable observer:observers)try{observer.run();}catch(RuntimeException ignored){}
  }
  NotificationManager nm=manager(c);
  if(!nm.areNotificationsEnabled()||(android.os.Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)||nm.getNotificationChannel(CHANNEL).getImportance()==NotificationManager.IMPORTANCE_NONE)return false;
  Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
  PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_inbox).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(pi).setAutoCancel(true).setShowWhen(true).setWhen(System.currentTimeMillis()).build();
  nm.notify("sms:"+token,100,n);
  return saved.edit().putBoolean(dedup,true).putString("alert_error","").commit();
 }catch(Exception e){try{Store.prefs(c).edit().putString("alert_error","اعلان نمایش داده نشد: "+e.getClass().getSimpleName()).apply();}catch(Exception ignored){}return false;}}
}
