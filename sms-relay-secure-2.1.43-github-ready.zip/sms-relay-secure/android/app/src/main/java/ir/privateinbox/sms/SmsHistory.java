package ir.privateinbox.sms;
import android.content.*;import android.content.pm.PackageManager;import android.database.Cursor;import android.provider.Telephony;import org.json.*;
final class SmsHistory {
 static void enqueue(Context c,String sender,String message,long timestamp)throws Exception{enqueue(c,sender,message,timestamp,false);}
 static void enqueue(Context c,String sender,String message,long timestamp,boolean live)throws Exception{enqueue(c,sender,message,timestamp,live,-1);}
 static synchronized void enqueue(Context c,String sender,String message,long timestamp,boolean live,int sim)throws Exception{enqueue(c,sender,message,timestamp,live,sim,-1);}
 static synchronized void enqueue(Context c,String sender,String message,long timestamp,boolean live,int sim,long rowId)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!"server".equals(p.getString("role","client")))return;
  if(!IncomingSim.accepts(c,sim))return;
  String id=Gateway.hash(Store.device(c)+"|"+sender+"|"+timestamp+"|"+message);
  String ledger="incoming_"+Gateway.hash(p.getString("site","")+"|"+p.getString("key","")+"|"+id);
  // A recorded message remains owned by the durable queue; scans never enqueue it again.
  if(p.getBoolean(ledger,false))return;
  boolean fresh=true;String name=ContactNames.lookup(c,sender);
  JSONObject body=new JSONObject().put("event_id",id).put("sender",sender).put("sender_name",name).put("message",message).put("sent_at",java.time.Instant.ofEpochMilli(timestamp).toString()).put("sim_id",sim);
  body.put("history_scope",initialScope(c)).put("bridge_kind",live?"new":"initial");if(!live)body.put("history_row_id",rowId);
  Outbox.add(c,p.getString("site",""),p.getString("key",""),"server/incoming",body,live);
  if(!p.edit().putBoolean(ledger,true).putInt(ledger+"_sim",sim).putString(ledger+"_name",name).putBoolean(ledger+"_live",live||p.getBoolean(ledger+"_live",false)).commit())throw new java.io.IOException("ثبت سابقه انتقال انجام نشد");
  ReceiveStatus.record(c,"stored",ReceiveStatus.now());if(live)MessageAlerts.show(c,Gateway.hash(sender+"|"+timestamp+"|"+message),sender,name,message);
 }
 static String initialScope(Context c)throws Exception{android.content.SharedPreferences p=Store.prefs(c);return "seed_v2_"+Gateway.hash(p.getString("site","")+"|"+Store.device(c));}
 static boolean queued(Context c,String sender,String body,long at)throws Exception{android.content.SharedPreferences p=Store.prefs(c);String id=Gateway.hash(Store.device(c)+"|"+sender+"|"+at+"|"+body);return p.getBoolean("incoming_"+Gateway.hash(p.getString("site","")+"|"+p.getString("key","")+"|"+id),false);}
 private static String cachedPlanScope="",cachedIds="";private static java.util.Set<Long> cachedPlan=new java.util.HashSet<>();
 static synchronized java.util.Set<Long> planIds(Context c)throws Exception{String scope=initialScope(c);String json=Store.prefs(c).getString(scope+"_ids","[]");if(!scope.equals(cachedPlanScope)||!json.equals(cachedIds)){JSONArray ids=new JSONArray(json);java.util.Set<Long> loaded=new java.util.HashSet<>();for(int i=0;i<ids.length();i++)loaded.add(ids.getLong(i));cachedPlan=loaded;cachedPlanScope=scope;cachedIds=json;}return cachedPlan;}
 static boolean permits(Context c,JSONObject body)throws Exception{if(!initialScope(c).equals(body.optString("history_scope")))return false;if("new".equals(body.optString("bridge_kind")))return true;return "initial".equals(body.optString("bridge_kind"))&&planIds(c).contains(body.optLong("history_row_id",-1));}
 private static final java.util.concurrent.locks.ReentrantLock scanLock=new java.util.concurrent.locks.ReentrantLock();
 static void configureDays(Context c,int days)throws Exception{
  if(days<1||days>3650)throw new IllegalArgumentException("days");scanLock.lock();try{android.content.SharedPreferences p=Store.prefs(c);String scope=initialScope(c);
   if(!p.edit().putInt("history_days",days).putLong(scope+"_restart_at",System.currentTimeMillis()).remove(scope+"_at").remove(scope+"_done").remove(scope+"_ids").commit())throw new java.io.IOException("ثبت بازه سابقه انجام نشد");
   ReceiveStatus.record(c,"history","بازه سابقه: "+days+" روز؛ در انتظار خواندن پیامک و انتقال.");
  }finally{scanLock.unlock();}
 }
 static void scan(Context c)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!"server".equals(p.getString("role","client")))return;
  if(c.checkSelfPermission(android.Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED){ReceiveStatus.record(c,"history","انتقال سابقه متوقف است: مجوز خواندن پیامک داده نشده؛ دریافت SMS جدید مستقل است.");return;}
  if(DeviceSims.list(c).length()==0)return;
  if(!scanLock.tryLock())return;
  try{String scope=initialScope(c);long cutoff=p.getLong(scope+"_at",0);
   if(cutoff==0){JSONObject remote=Network.call(p.getString("site",""),p.getString("key",""),"server/ping",null);int count=remote.optInt("initial_conversations",5);if(count<1||count>1000)throw new java.io.IOException("تعداد گفتگو در وردپرس معتبر نیست");String old=scope.replace("seed_v2_","seed_v1_");cutoff=p.getLong(scope+"_restart_at",p.getLong(old+"_at",System.currentTimeMillis()));int days=p.getInt("history_days",0);long from=days>0?Math.max(0,cutoff-days*86400000L):0;InitialSelection choose=new InitialSelection(count);JSONArray ids=new JSONArray();int chosenSim=IncomingSim.selected(c,DeviceSims.list(c));
    try(Cursor snapshot=c.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,new String[]{"address","body","date","date_sent",Telephony.Sms.SUBSCRIPTION_ID,"_id"},"date >= ? AND date < ?",new String[]{Long.toString(from),Long.toString(cutoff)},"date DESC")){if(snapshot==null)throw new java.io.IOException("صندوق پیامک در دسترس نیست");while(snapshot.moveToNext()){if(snapshot.getLong(2)>=cutoff||snapshot.getLong(2)<from)continue;int sim=snapshot.isNull(4)?-1:snapshot.getInt(4);if(chosenSim!=-2&&sim!=chosenSim)continue;String peer=snapshot.getString(0),body=snapshot.getString(1);if(peer==null)peer="unknown";if(body==null||body.isEmpty())continue;if(choose.take(peer.replaceAll("[^0-9A-Za-z]","")))ids.put(snapshot.getLong(5));}}
    if(!p.edit().putLong(scope+"_at",cutoff).putInt(scope+"_limit",count).putInt(scope+"_sim",chosenSim).putString(scope+"_ids",ids.toString()).commit())throw new java.io.IOException("ثبت فهرست انتقال اولیه انجام نشد");
   }
   Outbox.retireLegacyHistory(c);
   boolean done=p.getBoolean(scope+"_done",false);java.util.Set<Long> allowed=planIds(c);int initialAdded=0,newAdded=0;boolean remaining=false;int queue=Outbox.count(c);
   String where=done?"date >= ?":null;String[] args=done?new String[]{Long.toString(cutoff)}:null;
   try(Cursor cursor=c.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,new String[]{"address","body","date","date_sent",Telephony.Sms.SUBSCRIPTION_ID,"_id"},where,args,"date DESC")){
    if(cursor==null)throw new java.io.IOException("صندوق پیامک در دسترس نیست");
    while(cursor.moveToNext()){int sim=cursor.isNull(4)?-1:cursor.getInt(4);if(!IncomingSim.accepts(c,sim))continue;String sender=cursor.getString(0),body=cursor.getString(1);if(sender==null)sender="unknown";if(body==null||body.isEmpty())continue;long received=cursor.getLong(2),at=cursor.getLong(3);if(at<=0)at=received;boolean fresh=received>=cutoff;
     if(!fresh){if(done)continue;int seedSim=p.getInt(scope+"_sim",-1);if(seedSim!=-2&&sim!=seedSim)continue;if(!allowed.contains(cursor.getLong(5)))continue;}
     if(queued(c,sender,body,at))continue;
     if(fresh){if(newAdded>=50)continue;enqueue(c,sender,body,at,true,sim);newAdded++;}
     else{if(initialAdded>=20||queue+initialAdded>=100){remaining=true;continue;}enqueue(c,sender,body,at,false,sim,cursor.getLong(5));initialAdded++;}
    }
   }
   if(!done&&!remaining){if(!p.edit().putBoolean(scope+"_done",true).commit())throw new java.io.IOException("ثبت پایان انتقال اولیه انجام نشد");done=true;}
   ReceiveStatus.record(c,"history",done?"انتخاب سابقه اولیه پایان یافت؛ فقط پیام‌های جدید افزوده می‌شوند.":"انتقال اولیه مرحله‌ای: "+p.getInt(scope+"_limit",5)+" گفتگو؛ حداکثر ۲۰۰ پیام جدیدتر هر گفتگو");
  }finally{scanLock.unlock();}
 }
}
