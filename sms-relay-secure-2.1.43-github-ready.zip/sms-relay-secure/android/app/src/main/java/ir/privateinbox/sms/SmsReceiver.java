package ir.privateinbox.sms;
import android.content.*;import android.provider.Telephony;import android.telephony.SmsMessage;import org.json.*;
public class SmsReceiver extends BroadcastReceiver {
 private static final java.util.concurrent.ExecutorService executor=java.util.concurrent.Executors.newSingleThreadExecutor();
 @Override public void onReceive(Context context,Intent i){if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction()))return;
  Context c=context.getApplicationContext();ReceiveStatus.record(c,"broadcast",ReceiveStatus.now());PendingResult pending=goAsync();
  executor.execute(()->{try{android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!p.getString("role","client").equals("server")){ReceiveStatus.record(c,"error","دریافت دیده شد، اما حالت سرور یا اتصال فعال نیست.");return;}
   SmsMessage[] parts=Telephony.Sms.Intents.getMessagesFromIntent(i);if(parts==null||parts.length==0)throw new Exception("اطلاعات SMS در رویداد موجود نیست.");StringBuilder b=new StringBuilder();for(SmsMessage part:parts)if(part.getMessageBody()!=null)b.append(part.getMessageBody());
   int receivedSim=i.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX",i.getIntExtra("subscription",i.getIntExtra("subscription_id",-1)));if(!IncomingSim.accepts(c,receivedSim))return;String sender=parts[0].getOriginatingAddress()==null?"unknown":parts[0].getOriginatingAddress();SmsHistory.enqueue(c,sender,b.toString(),parts[0].getTimestampMillis(),true,receivedSim);MessageAlerts.show(c,Gateway.hash(sender+"|"+parts[0].getTimestampMillis()+"|"+b),sender,ContactNames.lookup(c,sender),b.toString());ReceiveStatus.record(c,"stored",ReceiveStatus.now());ReceiveStatus.record(c,"error","در صف انتقال خودکار");
  }catch(Exception e){ReceiveStatus.record(c,"error","ذخیره دریافت ناموفق: "+e.getClass().getSimpleName()+" — "+e.getMessage());}finally{pending.finish();}});
 }
}
