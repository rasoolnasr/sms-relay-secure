package ir.privateinbox.sms;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.widget.*;
import org.json.*;

/** Verified-email private-test onboarding. Secrets remain in Keystore-backed preferences. */
public class AccountActivity extends Activity {
 private static final String POLICY="2026-10-11";
 private final java.util.concurrent.ExecutorService executor=java.util.concurrent.Executors.newSingleThreadExecutor();
 private String site,token="",challenge="",accountId="",billingAccount="";private boolean billingReady=false;private PlaySubscriptions subscriptions;
 private TextView status; private EditText email,code; private Button start,verify,setup;
 private boolean autoSetup; private LinearLayout body; private CheckBox consent;
 @Override public void onCreate(Bundle state){
  super.onCreate(state);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
  site=getIntent().getStringExtra("site");autoSetup=getIntent().getBooleanExtra("auto_setup",false);
  try{java.net.URI u=new java.net.URI(site);if(!"https".equals(u.getScheme())||u.getHost()==null||u.getRawUserInfo()!=null||u.getRawQuery()!=null||u.getRawFragment()!=null)throw new Exception();}catch(Exception e){finish();return;}
  LinearLayout root=UI.root(this);ScrollView scroll=new ScrollView(this);root.addView(scroll);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);
  UI.text(this,body,autoSetup?"راه‌اندازی گوشی سرور":"حساب شما",24);
  UI.text(this,body,"سه روز استفاده آزمایشی، بدون پرداخت خودکار.\nسایت حساب: "+site+"\nکلید رمزگذاری پیام‌ها روی گوشی ساخته می‌شود؛ مدیر سایت آن را دریافت نمی‌کند.",15);
  email=UI.field(this,body,"ایمیل شما",false);email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
  consent=new CheckBox(this);consent.setText("موافقم ایمیل برای ورود و مدیریت حساب به سایت بالا ارسال شود. دوره آزمایشی سه روز است؛ بدون پرداخت خودکار.");body.addView(consent);
  start=UI.button(this,body,"دریافت کد ورود با ایمیل");code=UI.field(this,body,"کد شش‌رقمی ایمیل",false);code.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);verify=UI.button(this,body,"تأیید کد");verify.setEnabled(false);code.setVisibility(android.view.View.GONE);verify.setVisibility(android.view.View.GONE);
  status=UI.text(this,body,"",15);setup=UI.button(this,body,"راه‌اندازی خودکار گوشی سرور");setup.setEnabled(false);setup.setVisibility(android.view.View.GONE);
  LinearLayout mainBody=body;LinearLayout manage=new LinearLayout(this);manage.setOrientation(LinearLayout.VERTICAL);manage.setVisibility(android.view.View.GONE);UI.button(this,mainBody,"مدیریت حساب و اشتراک").setOnClickListener(v->manage.setVisibility(manage.getVisibility()==android.view.View.VISIBLE?android.view.View.GONE:android.view.View.VISIBLE));mainBody.addView(manage);body=manage;
  UI.button(this,body,"دستگاه‌های حساب و قطع دسترسی").setOnClickListener(v->devices());
  UI.button(this,body,"حذف حساب و داده‌های سایت").setOnClickListener(v->deleteDialog());
  UI.button(this,body,"خروج از حساب مشتری").setOnClickListener(v->{if(token.isEmpty())return;request("logout",new JSONObject(),j->{try{Store.prefs(this).edit().remove("account_token").remove("account_site").remove("account_id").commit();}catch(Exception ignored){}token="";accountId="";setup.setEnabled(false);status.setText("از حساب مشتری خارج شدید. اتصال صندوق روی گوشی‌های جفت‌شده با این گزینه قطع نمی‌شود؛ برای قطع، دستگاه را لغو کنید.");});});
  UI.button(this,body,"اشتراک و قیمت‌های Google Play").setOnClickListener(v->{if(billing()==null)return;subscriptions.plans();});
  UI.button(this,body,"بازیابی خرید Google Play").setOnClickListener(v->{if(billing()==null)return;subscriptions.restore();});
  UI.button(this,body,"مدیریت یا لغو اشتراک در Google Play").setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://play.google.com/store/account/subscriptions")));}catch(Exception e){status.setText("فروشگاه را باز کنید و از قسمت پرداخت‌ها، اشتراک‌ها را مدیریت کنید.");}});
  start.setOnClickListener(v->{if(!consent.isChecked()){status.setText("ابتدا توضیح ارسال ایمیل را تأیید کنید.");return;}String address=email.getText().toString().trim();if(!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()){status.setText("ایمیل معتبر وارد کنید.");return;}try{request("start",new JSONObject().put("email",address),j->{challenge=j.optString("challenge");code.setVisibility(android.view.View.VISIBLE);verify.setVisibility(android.view.View.VISIBLE);verify.setEnabled(true);email.setEnabled(false);status.setText("کد برای ارسال به ایمیل پذیرفته شد؛ پوشه هرزنامه را هم بررسی کنید. اعتبار ده دقیقه.");});}catch(Exception e){status.setText(e.getMessage());}});
  verify.setOnClickListener(v->{String value=code.getText().toString().trim();for(int digit=0;digit<10;digit++)value=value.replace((char)('۰'+digit),(char)('0'+digit)).replace((char)('٠'+digit),(char)('0'+digit));if(!value.matches("[0-9]{6}")||challenge.isEmpty()){status.setText("کد شش‌رقمی ایمیل را وارد کنید.");return;}try{request("verify",new JSONObject().put("challenge",challenge).put("code",value).put("policy",POLICY),j->{configureBilling(j);token=j.optString("token");accountId=String.valueOf(j.optLong("account_id"));code.setText("");challenge="";verify.setEnabled(false);try{if(!Store.prefs(this).edit().putString("account_token",token).putString("account_site",site).putString("account_id",accountId).commit())throw new Exception();setup.setEnabled(!j.optString("account_state").equals("deleting"));email.setVisibility(android.view.View.GONE);consent.setVisibility(android.view.View.GONE);start.setVisibility(android.view.View.GONE);code.setVisibility(android.view.View.GONE);verify.setVisibility(android.view.View.GONE);setup.setVisibility(android.view.View.VISIBLE);status.setText("حساب تأیید شد؛ کلیدها خودکار ساخته می‌شوند.");if(autoSetup&&!j.optString("account_state").equals("deleting"))bootstrap();}catch(Exception e){token="";status.setText("ذخیره امن حساب انجام نشد.");}});}catch(Exception e){status.setText(e.getMessage());}});
  setup.setOnClickListener(v->bootstrap());
  try{android.content.SharedPreferences p=Store.prefs(this);if(site.equals(p.getString("account_site",""))){token=p.getString("account_token","");accountId=p.getString("account_id","");if(!token.isEmpty())request("status",new JSONObject(),j->{configureBilling(j);setup.setEnabled(j.optBoolean("trial_active"));setup.setVisibility(android.view.View.VISIBLE);if(autoSetup&&j.optBoolean("trial_active")){bootstrap();return;}status.setText(j.optBoolean("trial_active")?"حساب متصل است؛ دسترسی آزمایشی یا اشتراک معتبر فعال است.":"دسترسی آزمایشی پایان یافته؛ خرید، مدیریت و حذف حساب در دسترس است.");});}}catch(Exception ignored){}
 }
 private interface Done{void run(JSONObject result)throws Exception;}
 private void request(String route,JSONObject data,Done done){
  if(!route.equals("start")&&!route.equals("verify")&&token.isEmpty()){status.setText("ابتدا با کد ایمیل وارد حساب شوید.");return;}
  start.setEnabled(false);verify.setEnabled(false);setup.setEnabled(false);status.setText("در حال ارتباط امن…");final String credential=token;
  executor.execute(()->{try{JSONObject result=Network.call(site,credential,"account/"+route,data);runOnUiThread(()->{if(isDestroyed())return;start.setEnabled(true);verify.setEnabled(!challenge.isEmpty());setup.setEnabled(!token.isEmpty());try{done.run(result);}catch(Exception e){status.setText("پاسخ کامل نشد: "+e.getMessage());}});}catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;start.setEnabled(true);verify.setEnabled(!challenge.isEmpty());setup.setEnabled(!token.isEmpty());status.setText("انجام نشد: "+e.getMessage());});}});
 }
 private void bootstrap(){
  if(token.isEmpty()||accountId.isEmpty()){status.setText("ابتدا وارد حساب شوید.");return;}
  try{
   android.content.SharedPreferences p=Store.prefs(this);String prefix="onboarding_"+Gateway.hash(site+"|"+accountId)+"_";
   String install=p.getString(prefix+"install",""),server=p.getString(prefix+"server",""),client=p.getString(prefix+"client",""),privateKey=p.getString(prefix+"private","");
   if(install.isEmpty()){install=EnvelopeCrypto.generate();server=EnvelopeCrypto.generate();client=EnvelopeCrypto.generate();privateKey=EnvelopeCrypto.generate();if(!p.edit().putString(prefix+"install",install).putString(prefix+"server",server).putString(prefix+"client",client).putString(prefix+"private",privateKey).commit())throw new Exception("ذخیره امن انجام نشد.");}
   final String connectionKey=server,encryptionKey=privateKey;
   JSONObject data=new JSONObject().put("install_id",install).put("server_key",server).put("client_key",client).put("label",android.os.Build.MODEL);
   request("bootstrap",data,j->{setResult(RESULT_OK,new Intent().putExtra("site",site).putExtra("key",connectionKey).putExtra("e2ee_key",encryptionKey));finish();});
  }catch(Exception e){status.setText("راه‌اندازی انجام نشد: "+e.getMessage());}
 }
 private void devices(){request("devices",new JSONObject(),j->{JSONArray rows=j.getJSONArray("devices");String[] labels=new String[rows.length()];for(int i=0;i<labels.length;i++){JSONObject d=rows.getJSONObject(i);labels[i]=d.optString("label")+" #"+d.optLong("id")+(d.optInt("enabled")==1?" — فعال":" — لغوشده");}new AlertDialog.Builder(this).setTitle("برای قطع دسترسی، دستگاه را انتخاب کنید").setItems(labels,(dialog,index)->{try{long id=rows.getJSONObject(index).getLong("id");new AlertDialog.Builder(this).setMessage("انتقال و دسترسی تمام کلاینت‌های این گوشی سرور قطع شود؟ سابقه هنوز ذخیره می‌ماند.").setPositiveButton("قطع دسترسی",(d,w)->{try{request("revoke",new JSONObject().put("device_id",id),x->status.setText("دسترسی این گوشی سرور و کلاینت‌های وابسته قطع شد."));}catch(Exception ignored){}}).setNegativeButton("انصراف",null).show();}catch(Exception ignored){}}).setPositiveButton("بستن",null).show();});}
 private void deleteDialog(){
  if(token.isEmpty()){status.setText("برای حذف حساب، ابتدا با ایمیل همان حساب وارد شوید.");return;}
  new AlertDialog.Builder(this).setTitle("حذف دائمی حساب").setMessage("حساب، پیام‌های سایت و تمام اتصال‌های متعلق به این حساب حذف می‌شوند. پیامک‌های اصلی گوشی پاک نمی‌شوند. این کار قابل بازگشت نیست. حذف حساب، اشتراک Google Play را لغو نمی‌کند؛ ابتدا از دکمه مدیریت اشتراک آن را لغو کنید. یک شناسه یک‌طرفه برای جلوگیری از تکرار دوره آزمایشی باقی می‌ماند؛ سیاست حذف نسخه پشتیبان را از سرویس‌دهنده بخواهید.").setPositiveButton("حذف دائمی",(d,w)->{try{request("delete",new JSONObject().put("confirm","DELETE"),j->{android.content.SharedPreferences p=Store.prefs(this);boolean same=site.equals(p.getString("site",""));p.edit().remove("account_token").remove("account_site").remove("account_id").commit();if(same){p.edit().putBoolean("enabled",false).putBoolean("logged_in",false).commit();stopService(new Intent(this,GatewayService.class));androidx.work.WorkManager.getInstance(this).cancelAllWork();}token="";setup.setEnabled(false);status.setText("حساب و داده‌های فعال سایت حذف شدند.");});}catch(Exception e){status.setText(e.getMessage());}}).setNegativeButton("انصراف",null).show();
 }
 private void configureBilling(JSONObject j){billingReady=j.optBoolean("billing_ready");billingAccount=j.optString("billing_account");if(subscriptions!=null){subscriptions.close();subscriptions=null;}}
 private PlaySubscriptions billing(){if(token.isEmpty()||!billingReady||!billingAccount.matches("[a-f0-9]{64}")){status.setText("ابتدا وارد حساب شوید. برای خرید، سرویس تأیید خرید و محصولات Google Play باید توسط صاحب برنامه تنظیم شوند.");return null;}if(subscriptions==null)subscriptions=new PlaySubscriptions(this,billingAccount,new PlaySubscriptions.Listener(){public void message(String text){runOnUiThread(()->{if(!isDestroyed())status.setText(text);});}public void purchase(String purchase){runOnUiThread(()->{if(isDestroyed())return;try{request("purchase",new JSONObject().put("purchase_token",purchase),j->{setup.setEnabled(true);status.setText("خرید توسط سرور و Google Play تأیید شد. پایان اعتبار: "+new java.util.Date(j.optLong("expires_at")*1000));});}catch(Exception e){status.setText("تأیید خرید انجام نشد؛ از بازیابی خرید دوباره تلاش کنید.");}});}});return subscriptions;}
 @Override protected void onDestroy(){if(subscriptions!=null)subscriptions.close();executor.shutdown();super.onDestroy();}
}
