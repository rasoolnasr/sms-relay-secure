package ir.privateinbox.sms;
import org.json.*;import java.util.*;
/** The physical server's selected SIM policy governs every SMS request. */
final class SmsRouting {
 static List<Integer> active(JSONArray sims){ArrayList<Integer> ids=new ArrayList<>();for(int slot=0;slot<2;slot++)for(int i=0;i<sims.length();i++){JSONObject sim=sims.optJSONObject(i);if(sim!=null&&sim.optInt("slot",-1)==slot&&sim.optInt("id",-1)>=0&&!ids.contains(sim.optInt("id")))ids.add(sim.optInt("id"));}return ids;}
 static List<Integer> resolve(JSONArray sims,int chosen){List<Integer> ids=active(sims);if(ids.isEmpty())throw new IllegalArgumentException("سیم‌کارت فعال وجود ندارد.");if(chosen==-3){if(ids.size()!=2)throw new IllegalArgumentException("برای ارسال با هر دو، دو سیم‌کارت فعال لازم است.");return ids;}if(chosen==-1)return java.util.Collections.singletonList(ids.get(0));if(!ids.contains(chosen))throw new IllegalArgumentException("سیم‌کارت انتخاب‌شده فعال نیست.");return java.util.Collections.singletonList(chosen);}
}
