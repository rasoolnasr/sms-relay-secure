package ir.privateinbox.sms;
import android.content.*;import android.content.pm.PackageManager;import android.database.Cursor;import android.net.Uri;import android.provider.ContactsContract;
final class ContactNames {
 static String lookup(Context c,String phone){if(c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED||phone==null||!phone.matches("[+]?[0-9 ()-]{3,32}"))return "";
  String digits=phone.replaceAll("[^0-9]","");java.util.LinkedHashSet<String> candidates=new java.util.LinkedHashSet<>();candidates.add(phone);candidates.add(digits);if(phone.startsWith("+")||digits.length()>10)candidates.add("+"+digits);if(digits.length()==11&&digits.startsWith("1"))candidates.add(digits.substring(1));
  for(String candidate:candidates){Uri uri=Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,Uri.encode(candidate));
   try(Cursor rows=c.getContentResolver().query(uri,new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},null,null,null)){if(rows!=null&&rows.moveToFirst()){String name=rows.getString(0);if(name!=null&&!name.trim().isEmpty()){name=name.trim();return name.substring(0,Math.min(256,name.length()));}}}catch(Exception ignored){}
  }return "";
 }
}
