package ir.privateinbox.sms;
import java.util.*;
final class InitialSelection {
 final int limit;final Map<String,Integer> counts=new LinkedHashMap<>();
 InitialSelection(int limit){this.limit=Math.max(1,Math.min(1000,limit));}
 boolean take(String peer){int used=counts.getOrDefault(peer,0);if(used==0&&counts.size()>=limit)return false;if(used>=200)return false;counts.put(peer,used+1);return true;}
}
