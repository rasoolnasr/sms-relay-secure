package ir.privateinbox.sms;
import android.content.Context;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class UploadWorker extends Worker {
 public UploadWorker(Context c,WorkerParameters p){super(c,p);}
 static void schedule(Context c){OneTimeWorkRequest job=new OneTimeWorkRequest.Builder(UploadWorker.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build();WorkManager.getInstance(c).enqueueUniqueWork("sms-upload",ExistingWorkPolicy.KEEP,job);}
 @Override public Result doWork(){try{if(!Store.prefs(getApplicationContext()).getBoolean("enabled",false))return Result.success();Outbox.flush(getApplicationContext());return Outbox.count(getApplicationContext())==0?Result.success():Result.retry();}catch(Exception e){Store.status(getApplicationContext(),"ارسال به سایت ناموفق؛ داده در صف امن باقی است.");return Result.retry();}}
}
