package ir.privateinbox.sms;
import android.content.*;import android.content.pm.PackageManager;import org.json.*;
final class ContactSync {
 private static long next=0;private static int page=0;private static String scope="";
 static void tick(Context c)throws Exception{
  if(c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){c.getSharedPreferences("contact-status",0).edit().putString("last","مجوز خواندن مخاطبان فعال نیست.").apply();return;}
  android.content.SharedPreferences p=Store.prefs(c);String current=p.getString("site","")+"|"+p.getString("key","");if(!scope.equals(current)){scope=current;page=0;next=0;}
  long now=android.os.SystemClock.elapsedRealtime();if(now<next)return;next=now+30000;
  JSONObject feed=Network.call(p.getString("site",""),p.getString("key",""),"server/feed&layout=threads&page="+page,null);int matched=0;JSONArray rows=feed.optJSONArray("items"),names=new JSONArray();if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;String number=row.optString("peer"),name=ContactNames.lookup(c,number);if(!name.isEmpty())matched++;if(!name.isEmpty()&&!name.equals(row.optString("peer_name")))names.put(new JSONObject().put("number",number).put("name",name));}
  if(names.length()>0)Network.call(p.getString("site",""),p.getString("key",""),"server/contact_names",new JSONObject().put("contacts",names));c.getSharedPreferences("contact-status",0).edit().putString("last","بررسی مخاطبان: "+(rows==null?0:rows.length())+" گفتگو؛ "+matched+" نام پیدا شد؛ "+names.length()+" نام به سایت منتقل شد.").apply();page=feed.optBoolean("has_more")?page+1:0;
 }
}
