package ir.privateinbox.sms;
import android.content.*;import android.telephony.SmsManager;import android.app.PendingIntent;import org.json.*;import java.util.*;
final class Gateway {
 static String hash(String s)throws Exception{byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:digest)b.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return b.toString();}
 static synchronized void tick(Context c)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!p.getString("role","client").equals("server"))return;UploadWorker.schedule(c);DeliveryReports.recover(c);UssdRuntime.recover(c);if(UssdRuntime.busy())return;
  if(c.checkSelfPermission(android.Manifest.permission.SEND_SMS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){Store.status(c,"ارسال غیرفعال است: مجوز ارسال SMS داده نشده؛ دریافت پیام‌های جدید مستقل است.");return;}
  String site=p.getString("site",""),key=p.getString("key","");JSONObject j=Network.call(site,key,"server/claim",new JSONObject());if(j.isNull("command")){Store.status(c,"سرور متصل است — "+java.time.Instant.now());return;}
  JSONObject cmd=j.getJSONObject("command");if(!E2ee.consume(c,site,cmd))return;if(cmd.optString("kind","sms").equals("ussd")){UssdRuntime.dispatch(c,site,key,cmd);return;}String journal="job_"+hash(site+"|"+key+"|"+cmd.getLong("id"));
  synchronized(Store.class){if(p.contains(journal))return;List<Integer> subscriptions;try{subscriptions=SmsRouting.resolve(DeviceSims.list(c),p.getInt("send_sim_id",-1));}catch(Exception unavailable){if(!p.edit().putString(journal,"sim_unavailable").commit())throw new java.io.IOException("Journal not saved");Outbox.add(c,site,key,"server/result",new JSONObject().put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("status","failed").put("detail","server_selected_sim_unavailable"));Store.status(c,unavailable.getMessage());return;}
   ArrayList<SmsManager> managers=new ArrayList<>();ArrayList<ArrayList<String>> messages=new ArrayList<>();int totalParts=0;
   for(int sub:subscriptions){SmsManager manager=android.os.Build.VERSION.SDK_INT>=31?c.getSystemService(SmsManager.class).createForSubscriptionId(sub):SmsManager.getSmsManagerForSubscriptionId(sub);ArrayList<String> parts=manager.divideMessage(cmd.getString("message"));managers.add(manager);messages.add(parts);totalParts+=parts.size();}

   JSONArray partSims=new JSONArray(),deliveryStates=new JSONArray();for(int n=0;n<subscriptions.size();n++)for(int k=0;k<messages.get(n).size();k++){partSims.put(subscriptions.get(n));deliveryStates.put("pending");}
   JSONObject record=new JSONObject().put("site",site).put("key",key).put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("parts",totalParts).put("sim_ids",new JSONArray(subscriptions)).put("done",new JSONArray()).put("failed",false).put("part_sims",partSims).put("delivery_states",deliveryStates).put("delivery_revision",1).put("delivery_requested_at",java.time.Instant.now().toString());
   // Persist intent-to-send BEFORE touching the SIM; a crash will not cause an automatic resend.
   if(!p.edit().putString(journal,record.toString()).commit())throw new java.io.IOException("Journal not saved");
   DeliveryReports.enqueue(c,journal,record);
   try{int offset=0;for(int sim=0;sim<managers.size();sim++){ArrayList<String> parts=messages.get(sim);ArrayList<PendingIntent> sent=new ArrayList<>(),delivered=new ArrayList<>();for(int k=0;k<parts.size();k++){int part=offset+k;Intent callback=new Intent(c,SentReceiver.class).setAction("ir.privateinbox.sms.SENT").setData(android.net.Uri.parse("smsbridge://sent/"+journal+"/"+part)).putExtra("journal",journal).putExtra("part",part);sent.add(PendingIntent.getBroadcast(c,part,callback,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));Intent receipt=new Intent(c,DeliveryReceiver.class).setAction("ir.privateinbox.sms.DELIVERED").setData(android.net.Uri.parse("smsbridge://delivered/"+journal+"/"+part)).putExtra("journal",journal).putExtra("part",part);int flags=PendingIntent.FLAG_UPDATE_CURRENT|(android.os.Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);delivered.add(PendingIntent.getBroadcast(c,part,receipt,flags));}
    managers.get(sim).sendMultipartTextMessage(cmd.getString("to"),null,parts,sent,delivered);offset+=parts.size();}

    Outbox.add(c,site,key,"server/result",new JSONObject().put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("status","submitted"));Store.status(c,"درخواست به سیستم SMS گوشی تحویل داده شد؛ سیم‌کارت‌ها: "+subscriptions);
   }catch(Exception e){Outbox.add(c,site,key,"server/result",new JSONObject().put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("status","unknown").put("detail","dispatch_exception_no_auto_retry"));Store.status(c,"نتیجه ارسال نامعلوم؛ برای جلوگیری از تکرار، خودکار دوباره ارسال نمی‌شود.");}
  }
 }
}
