package ir.privateinbox.sms;
import android.content.*;import android.content.pm.PackageManager;import android.telephony.*;import org.json.*;
final class DeviceSims {
 private static long last=0;
 static JSONArray list(Context c)throws Exception{JSONArray out=new JSONArray();if(c.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)return out;java.util.List<SubscriptionInfo> infos=c.getSystemService(SubscriptionManager.class).getActiveSubscriptionInfoList();if(infos!=null)for(SubscriptionInfo i:infos){if(i.getSimSlotIndex()<0)continue;String name=i.getCarrierName()==null?"":i.getCarrierName().toString();out.put(new JSONObject().put("id",i.getSubscriptionId()).put("slot",i.getSimSlotIndex()).put("name",name.substring(0,Math.min(100,name.length()))));}return out;}
 static boolean active(Context c,int id)throws Exception{JSONArray a=list(c);for(int i=0;i<a.length();i++)if(a.getJSONObject(i).getInt("id")==id)return true;return false;}
 static void tick(Context c)throws Exception{if(last!=0&&android.os.SystemClock.elapsedRealtime()-last<30000)return;android.content.SharedPreferences p=Store.prefs(c);Network.call(p.getString("site",""),p.getString("key",""),"server/device_info",new JSONObject().put("sims",list(c)));last=android.os.SystemClock.elapsedRealtime();}
 static String label(JSONObject s){return "سیم‌کارت "+(s.optInt("slot",0)+1)+" — "+s.optString("name","");}
}
