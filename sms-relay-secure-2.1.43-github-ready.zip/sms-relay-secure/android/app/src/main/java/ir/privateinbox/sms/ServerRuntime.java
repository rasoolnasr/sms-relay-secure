package ir.privateinbox.sms;
import android.content.Context;
import android.os.PowerManager;
final class ServerRuntime {
 static void tick(Context c)throws Exception{
  PowerManager.WakeLock lock=c.getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"smsbridge:queue");
  lock.acquire(120000);try{if("client".equals(Store.prefs(c).getString("role","")))ClientAlerts.tick(c);else Gateway.tick(c);}finally{if(lock.isHeld())lock.release();}
 }
 static boolean enabled(Context c)throws Exception{return Store.prefs(c).getBoolean("enabled",false)&&(Store.prefs(c).getString("role","client").equals("server")||Store.prefs(c).getString("role","client").equals("client"));}
 static void schedule(Context c){androidx.work.PeriodicWorkRequest job=new androidx.work.PeriodicWorkRequest.Builder(ServerWatchdog.class,15,java.util.concurrent.TimeUnit.MINUTES).setConstraints(new androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()).build();androidx.work.WorkManager.getInstance(c).enqueueUniquePeriodicWork("sms-server-watchdog",androidx.work.ExistingPeriodicWorkPolicy.KEEP,job);}
}
