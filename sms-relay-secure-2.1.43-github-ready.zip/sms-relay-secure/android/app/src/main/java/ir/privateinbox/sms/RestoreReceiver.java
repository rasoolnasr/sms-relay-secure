package ir.privateinbox.sms;
import android.content.*;
public class RestoreReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){String a=i.getAction();if(!Intent.ACTION_BOOT_COMPLETED.equals(a)&&!Intent.ACTION_MY_PACKAGE_REPLACED.equals(a))return;try{if(!ServerRuntime.enabled(c))return;ServerRuntime.schedule(c);UploadWorker.schedule(c);try{c.startForegroundService(new Intent(c,GatewayService.class));}catch(Exception e){Store.status(c,"راه‌اندازی مستقیم سرویس محدود شد؛ بازیابی دوره‌ای فعال است.");}}catch(Exception ignored){}}
}
