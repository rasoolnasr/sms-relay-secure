package ir.privateinbox.sms;
import java.security.*;import java.security.spec.*;import java.util.Base64;import javax.crypto.*;import javax.crypto.spec.SecretKeySpec;
/** Ephemeral P-256 ECDH, bound to a QR-only secret which the relay never receives. */
final class PairCrypto {
 static KeyPair generate()throws Exception{KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new ECGenParameterSpec("secp256r1"));return g.generateKeyPair();}
 static String publicKey(KeyPair p){return Base64.getEncoder().encodeToString(p.getPublic().getEncoded());}
 static byte[] shared(KeyPair ours,String peer,String qrSecret,String context)throws Exception{
  byte[] encoded=Base64.getDecoder().decode(peer);if(encoded.length!=91)throw new SecurityException("Invalid pairing key");
  PublicKey pub=KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(encoded));
  java.security.interfaces.ECPublicKey ec=(java.security.interfaces.ECPublicKey)pub;
  java.security.interfaces.ECPublicKey own=(java.security.interfaces.ECPublicKey)ours.getPublic();
  if(!ec.getParams().getCurve().equals(own.getParams().getCurve())||!ec.getParams().getOrder().equals(own.getParams().getOrder())||!ec.getParams().getGenerator().equals(own.getParams().getGenerator())||ec.getParams().getCofactor()!=own.getParams().getCofactor())throw new SecurityException("Wrong curve");
  KeyAgreement a=KeyAgreement.getInstance("ECDH");a.init(ours.getPrivate());a.doPhase(pub,true);
  Mac extract=Mac.getInstance("HmacSHA256");extract.init(new SecretKeySpec(EnvelopeCrypto.key(qrSecret),"HmacSHA256"));byte[] prk=extract.doFinal(a.generateSecret());
  Mac expand=Mac.getInstance("HmacSHA256");expand.init(new SecretKeySpec(prk,"HmacSHA256"));expand.update(("smsbridge/pair1/"+context).getBytes(java.nio.charset.StandardCharsets.UTF_8));return expand.doFinal(new byte[]{1});
 }
}
