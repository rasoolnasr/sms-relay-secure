package ir.privateinbox.sms;
import android.content.*;
import androidx.work.*;
public class ServerWatchdog extends Worker {
 public ServerWatchdog(Context c,WorkerParameters p){super(c,p);}
 @Override public Result doWork(){Context c=getApplicationContext();try{if(!ServerRuntime.enabled(c))return Result.success();try{c.startForegroundService(new Intent(c,GatewayService.class));}catch(Exception e){Store.status(c,"بازیابی سرویس توسط اندروید محدود شد؛ بررسی صف دوره‌ای ادامه دارد.");}ServerRuntime.tick(c);return Result.success();}catch(Exception e){Store.status(c,"اتصال موقتاً قطع است؛ خودکار دوباره بررسی می‌شود: "+e.getMessage());return Result.retry();}}
}
