package ir.privateinbox.sms;
import android.content.*;import android.telephony.SmsMessage;
public class DeliveryReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){String journal=i.getStringExtra("journal");if(journal==null||!journal.matches("job_[a-f0-9]{64}"))return;String state="unconfirmed";try{byte[] pdu=i.getByteArrayExtra("pdu");String format=i.getStringExtra("format");if(pdu!=null&&("3gpp".equals(format)||"3gpp2".equals(format))){SmsMessage m=SmsMessage.createFromPdu(pdu,format);if(m!=null&&m.isStatusReportMessage())state=DeliveryReports.classify(format,m.getStatus());}DeliveryReports.update(c,journal,i.getIntExtra("part",-1),state);}catch(Exception e){Store.status(c,"ثبت گزارش تحویل پیامک ناموفق؛ پیامک دوباره ارسال نمی‌شود.");}}
}
