package ir.privateinbox.sms;
public final class BridgeApp extends android.app.Application {
 static android.content.Context context;
 @Override public void onCreate(){super.onCreate();context=getApplicationContext();}
}
