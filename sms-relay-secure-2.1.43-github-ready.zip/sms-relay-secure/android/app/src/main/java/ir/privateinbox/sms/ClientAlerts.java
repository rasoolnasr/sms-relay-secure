package ir.privateinbox.sms;
import android.content.*;import org.json.*;
final class ClientAlerts {
 static synchronized void tick(Context c)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!"client".equals(p.getString("role","")))return;JSONObject metadata=Network.call(p.getString("site",""),p.getString("key",""),"client/ping",null);int selected=IncomingSim.selected(c,metadata.optJSONArray("sims"));if(selected<0&&selected!=-2)return;String marker="alerts_"+Gateway.hash(p.getString("site","")+"|"+p.getString("key","")+"|sim:"+selected);long previous=p.getLong(marker,-1);long highest=previous;int page=0;
  boolean delivered=true;
  do{JSONObject feed=Network.call(p.getString("site",""),p.getString("key",""),"client/feed?layout=messages&history_limit=100&page="+page+(selected==-2?"":"&sim="+selected),null);JSONArray rows=feed.optJSONArray("items");boolean newer=false;if(rows!=null)for(int i=rows.length()-1;i>=0;i--){JSONObject row=rows.optJSONObject(i);if(row==null||!"in".equals(row.optString("direction")))continue;long id=row.optLong("id");highest=Math.max(highest,id);if(previous>=0&&id>previous){newer=true;delivered=MessageAlerts.show(c,marker+"_"+id,row.optString("peer"),row.optString("peer_name"),row.optString("message"))&&delivered;}}
   ClientReceipts.ack(c,p.getString("site",""),p.getString("key",""),rows);
   if(previous<0||!feed.optBoolean("has_more")||!newer)break;page++;
  }while(page<20);
  if(highest<0)highest=0;if(delivered)p.edit().putLong(marker,highest).commit();
 }
}
