package ir.privateinbox.sms;
import android.accessibilityservice.AccessibilityService;import android.view.accessibility.*;import android.os.Bundle;import java.util.*;
/** Restricted to known telephony packages, during an explicitly requested USSD session. */
public class UssdAccessibility extends AccessibilityService {
 static volatile UssdAccessibility instance;
 private static final Set<String> PACKAGES=new HashSet<>(Arrays.asList("com.android.phone","com.android.server.telecom","com.samsung.android.app.telephonyui","com.samsung.android.dialer","com.google.android.dialer","com.android.dialer"));
 @Override protected void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent event){if(!InteractiveUssd.busy())return;Dialog d=dialog();if(d!=null)InteractiveUssd.prompt(this,d.text,d.edit!=null);}
 @Override public void onInterrupt(){InteractiveUssd.end(this,"unknown","دسترسی‌پذیری نشست قطع شد.");}
 @Override public void onDestroy(){instance=null;InteractiveUssd.end(this,"unknown","سرویس USSD بسته شد.");super.onDestroy();}
 private static class Dialog{AccessibilityNodeInfo edit,positive,cancel;String text="";}
 private Dialog dialog(){AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null||!PACKAGES.contains(String.valueOf(root.getPackageName())))return null;List<AccessibilityNodeInfo> positive=root.findAccessibilityNodeInfosByViewId("android:id/button1");if(positive.size()!=1||!positive.get(0).isEnabled())return null;Dialog d=new Dialog();d.positive=positive.get(0);List<AccessibilityNodeInfo> negative=root.findAccessibilityNodeInfosByViewId("android:id/button2");if(negative.size()==1)d.cancel=negative.get(0);StringBuilder text=new StringBuilder();walk(root,d,text,0);d.text=text.toString().trim();if(d.text.isEmpty()||(d.edit!=null&&d.cancel==null))return null;return d;}
 private void walk(AccessibilityNodeInfo n,Dialog d,StringBuilder text,int depth){if(depth>25||text.length()>4000)return;if(n.isEditable()){if(d.edit==null)d.edit=n;return;}String id=String.valueOf(n.getViewIdResourceName());if(!id.startsWith("android:id/button")&&n.getChildCount()==0&&n.getText()!=null){if(text.length()>0)text.append('\n');text.append(n.getText());}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo child=n.getChild(i);if(child!=null)walk(child,d,text,depth+1);}}
 boolean reply(String answer,String expected){Dialog d=dialog();if(d==null||d.edit==null||!d.text.equals(expected))return false;Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,answer);if(!d.edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return false;return d.positive.performAction(AccessibilityNodeInfo.ACTION_CLICK);}
 boolean cancelDialog(){Dialog d=dialog();String expected=InteractiveUssd.expectedPrompt();return d!=null&&!expected.isEmpty()&&expected.equals(d.text)&&d.cancel!=null&&d.cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK);}
}
