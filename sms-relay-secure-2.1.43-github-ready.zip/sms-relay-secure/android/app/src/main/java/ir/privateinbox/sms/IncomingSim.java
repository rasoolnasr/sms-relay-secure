package ir.privateinbox.sms;
import android.content.Context;import org.json.*;
final class IncomingSim {
 static int preferred(JSONArray sims,int slot){if(sims==null||sims.length()==0)return -1;for(int i=0;i<sims.length();i++){JSONObject s=sims.optJSONObject(i);if(s!=null&&s.optInt("slot",-1)==slot)return s.optInt("id",-1);}if(sims.length()==1)return sims.optJSONObject(0).optInt("id",-1);return -1;}
 static int selected(Context c,JSONArray sims)throws Exception{int slot=Store.prefs(c).getInt("incoming_sim_slot",1);return slot==-2?-2:preferred(sims,slot);}
 static boolean accepts(Context c,int sim)throws Exception{int selected=selected(c,DeviceSims.list(c));return selected==-2||(selected>=0&&sim==selected);}
}
