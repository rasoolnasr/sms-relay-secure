package ir.privateinbox.sms;
import android.app.Activity;import android.view.*;import android.widget.*;
final class UI {
 static int dp(Activity a,int n){return (int)(n*a.getResources().getDisplayMetrics().density);}
 static LinearLayout root(Activity a){LinearLayout l=new LinearLayout(a);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);l.setBackgroundColor(0xfff8fafc);int p=dp(a,16);l.setPadding(p,p,p,p);l.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(p,p+i.getSystemWindowInsetTop(),p,p+i.getSystemWindowInsetBottom());return i;});a.setContentView(l);return l;}
 static TextView text(Activity a,LinearLayout l,String s,int size){TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(0xff173b67);t.setPadding(0,dp(a,8),0,dp(a,8));l.addView(t);return t;}
 static Button button(Activity a,LinearLayout l,String s){Button b=new Button(a);b.setText(s);b.setTextSize(16);b.setTextColor(0xffffffff);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff173b67));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(a,52));p.setMargins(0,dp(a,8),0,0);l.addView(b,p);return b;}
 static EditText field(Activity a,LinearLayout l,String hint,boolean password){EditText e=new EditText(a);e.setHint(hint);e.setSingleLine(true);if(password)e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);e.setTextSize(16);e.setTextDirection(View.TEXT_DIRECTION_LTR);e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|(password?android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD:android.text.InputType.TYPE_TEXT_VARIATION_URI));l.addView(e,new LinearLayout.LayoutParams(-1,dp(a,56)));return e;}
}
