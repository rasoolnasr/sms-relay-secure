# اطلاعات انتشار Google Play — پیش‌نویس

نام فعلی برنامه: صندوق خصوصی پیامک

توضیح کوتاه پیشنهادی: انتقال پیامک بین گوشی‌های شما با کلید رمزگذاری مستقل

توضیح محصول: این برنامه پیامک گوشی اندرویدی دارای سیم‌کارت را به گوشی‌های مورد اعتماد شما منتقل می‌کند. یک گوشی نقش سرور و گوشی دیگر نقش کلاینت دارد. اتصال به افزونه وردپرس سازگار و HTTPS لازم است. متن و اطلاعات مخاطب پیش از انتقال روی دستگاه رمز می‌شوند؛ کلید مستقل فقط روی گوشی‌های مجاز نگهداری می‌شود. پیامک‌های RCS، صدا و تماس تلفنی پشتیبانی نمی‌شوند. ارسال از سیم‌کارت سرور ممکن است هزینه اپراتور داشته باشد. امکان دریافت لحظه‌ای به اینترنت و محدودیت‌های پس‌زمینه گوشی وابسته است.

این متن پیش‌نویس است؛ تا پایان موانع RELEASE-STATUS-FA.md در فروشگاه منتشر نشود.

## Data Safety: نقشه اولیه، نه پاسخ نهایی فرم

| داده | استفاده | وضعیت |
|---|---|---|
| SMS، شماره و نام مخاطب | انتقال بین دستگاه‌های انتخابی | محتوا در این نسخه پیش از انتقال رمز می‌شود |
| شناسه نصب و نام دستگاه | اتصال و نمایش وضعیت | سایت می‌بیند |
| اطلاعات سیم‌کارت، زمان و وضعیت | مسیریابی و وضعیت | سایت می‌بیند |
| خرید/حساب/شناسه لایسنس | فروش و مجوز | هنوز اجرا نشده؛ پس از اتصال خرید باید به اظهارنامه اضافه شود |

رمزگذاری به‌تنهایی به معنی انتخاب «هیچ داده‌ای جمع‌آوری نمی‌شود» نیست. پاسخ‌ها باید با محصول نهایی، ارائه‌دهنده خدمات و SDKهای نهایی تطبیق داده شوند. در این نسخه SDK تبلیغات/analytics اضافه نشده است.

## اظهارنامه SMS پیشنهادی

Core purpose: User-controlled cross-device synchronization and transfer of SMS between the user's Android gateway and trusted client devices. READ_SMS imports the configured initial history and reconciles newly received SMS. RECEIVE_SMS detects incoming messages. SEND_SMS executes requests explicitly initiated by the user on a trusted client. Client-only users do not require SMS permissions. No SMS data is used for advertising.

ویدئوی واقعی لازم: انتخاب سرور، نمایش رضایت، مجوزها، ساخت/انتقال امن کلید مستقل، دریافت SMS واقعی، نمایش در کلاینت، ارسال پاسخ و توقف انتقال. پذیرش این استثنا با گوگل است.

## اقدامات صاحب حساب

- انتخاب نام تجاری/ناشر، کشور فروش و ایمیل پشتیبانی.
- تأیید حساب Play Console؛ نوع و تاریخ ساخت حساب تعیین‌کننده مسیر تست است.
- ساخت محصولات/اشتراک‌ها و مجوز Android Publisher API برای سرور تأیید خرید.
- فعال‌سازی Play App Signing، ثبت upload key اختصاصی و امضای AAB.
- انتشار سیاست حریم خصوصی و مسیر حذف حساب/داده با دامنه HTTPS واقعی.
- تهیه آیکن ۵۱۲×۵۱۲، feature graphic ۱۰۲۴×۵۰۰ و اسکرین‌شات از نسخه نهایی واقعی؛ تصویر این بسته نباید به‌عنوان اثبات کارکرد استفاده شود.
- ساخت حساب بررسی با داده ساختگی و دسترسی محدود؛ بدون پیام واقعی مشتریان.
- تست بسته و پیش‌راه‌اندازی؛ حساب‌های شخصی جدید مشمول شرایط فعلی ۱۲ تست‌کننده برای ۱۴ روز پیوسته می‌شوند.

## منابع رسمی بررسی‌شده

https://support.google.com/googleplay/android-developer/answer/11926878
https://support.google.com/googleplay/android-developer/answer/10208820
https://support.google.com/googleplay/android-developer/answer/10144311
https://support.google.com/googleplay/android-developer/answer/10964491
https://support.google.com/googleplay/android-developer/answer/14151465
https://developer.android.com/google/play/billing
